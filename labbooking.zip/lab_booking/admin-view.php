<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Authentication Check
function isAdmin() {
    return isset($_SESSION['username']) && $_SESSION['username'] === 'admin_user';
}

if (!isAdmin()) {
    header("Location: login.php");
    exit();
}

// Handle Logout Request
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Database Connection
$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    error_log("DB Connection Error: " . $conn->connect_error);
    die("Database connection failed.");
}

// Get filter values from GET/POST
$filter_time = isset($_GET['filter_time']) ? $_GET['filter_time'] : '';
$filter_block = isset($_GET['filter_block']) ? $_GET['filter_block'] : '';
$filter_lab = isset($_GET['filter_lab']) ? $_GET['filter_lab'] : '';
$filter_capacity = isset($_GET['filter_capacity']) ? $_GET['filter_capacity'] : '';
$filter_status = isset($_GET['filter_status']) ? $_GET['filter_status'] : 'all';
$view_mode = isset($_GET['view_mode']) ? $_GET['view_mode'] : 'grid';

// Build WHERE clause for filtering
$where_conditions = [];

if (!empty($filter_time)) {
    $where_conditions[] = "start_time = '$filter_time'";
}

if (!empty($filter_block)) {
    $where_conditions[] = "block = '$filter_block'";
}

if (!empty($filter_lab)) {
    $where_conditions[] = "lab LIKE '%$filter_lab%'";
}

if (!empty($filter_capacity)) {
    $where_conditions[] = "capacity >= $filter_capacity";
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

// Fetch data based on status filter
$fixed_bookings = [];
$live_bookings = [];
$completed_bookings = [];
$all_bookings = [];

$current_day_name = date('l');
$current_time = date('H:i:s');

// Get Fixed Bookings (from fixed_bookings table)
$fixed_sql = "SELECT 'fixed' as type, id, lab, block, day, start_time, end_time, course, capacity FROM fixed_bookings $where_clause ORDER BY day, start_time";
$fixed_result = $conn->query($fixed_sql);
if ($fixed_result) {
    while ($row = $fixed_result->fetch_assoc()) {
        $fixed_bookings[] = $row;
    }
}

// Get Live Bookings (currently happening)
$live_sql = "SELECT 'live' as type, id, lab, block, day, start_time, end_time, username, reason, phone FROM bookings 
             WHERE day = '$current_day_name' AND start_time <= '$current_time' AND end_time > '$current_time' AND deleted = 0 $where_clause ORDER BY start_time";
$live_result = $conn->query($live_sql);
if ($live_result) {
    while ($row = $live_result->fetch_assoc()) {
        $live_bookings[] = $row;
    }
}

// Get Completed Bookings (from booked_labs history)
$completed_sql = "SELECT 'completed' as type, id, lab, block, day, start_time, end_time, username, reason FROM booked_labs $where_clause ORDER BY day DESC, start_time DESC LIMIT 50";
$completed_result = $conn->query($completed_sql);
if ($completed_result) {
    while ($row = $completed_result->fetch_assoc()) {
        $completed_bookings[] = $row;
    }
}

// Get All Active Bookings
$all_sql = "SELECT 'active' as type, id, lab, block, day, start_time, end_time, username, reason, phone FROM bookings WHERE deleted = 0 $where_clause ORDER BY day, start_time";
$all_result = $conn->query($all_sql);
if ($all_result) {
    while ($row = $all_result->fetch_assoc()) {
        $all_bookings[] = $row;
    }
}

// Get unique values for filter dropdowns
$blocks_result = $conn->query("SELECT DISTINCT block FROM labs ORDER BY block");
$blocks = [];
while ($row = $blocks_result->fetch_assoc()) {
    $blocks[] = $row['block'];
}

$labs_result = $conn->query("SELECT DISTINCT lab FROM labs ORDER BY lab");
$labs = [];
while ($row = $labs_result->fetch_assoc()) {
    $labs[] = $row['lab'];
}

$time_slots = ['08:30', '09:30', '10:30', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];
$capacities = [30, 45, 60];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Bookings - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .admin-badge {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Filter Section */
        .filter-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .filter-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .filter-title i {
            color: var(--accent-primary);
        }

        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1.5rem;
            align-items: end;
            margin-bottom: 1.5rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .form-select,
        .form-input {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-select:focus,
        .form-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-select option {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .filter-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .search-btn,
        .reset-btn {
            padding: 0.75rem 2rem;
            border: none;
            border-radius: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .search-btn {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
        }

        .search-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .reset-btn {
            background: var(--bg-tertiary);
            color: var(--text-secondary);
            border: 1px solid var(--border-color);
        }

        .reset-btn:hover {
            background: var(--border-color);
            color: var(--text-primary);
        }

        /* View Mode Toggle */
        .view-toggle {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .toggle-btn {
            padding: 0.75rem 1.5rem;
            border: 1px solid var(--border-color);
            background: var(--bg-tertiary);
            color: var(--text-secondary);
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 500;
        }

        .toggle-btn.active {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border-color: var(--accent-primary);
        }

        .toggle-btn:hover {
            border-color: var(--accent-primary);
        }

        /* Status Tabs */
        .status-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }

        .status-tab {
            padding: 0.75rem 1.5rem;
            border: 2px solid var(--border-color);
            background: transparent;
            color: var(--text-secondary);
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .status-tab:hover {
            border-color: var(--accent-primary);
            color: var(--text-primary);
        }

        .status-tab.active {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border-color: var(--accent-primary);
        }

        /* Grid View */
        .grid-view {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .booking-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            transition: all 0.3s ease;
            border-left: 4px solid var(--accent-primary);
        }

        .booking-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .booking-card.fixed {
            border-left-color: var(--accent-warning);
        }

        .booking-card.live {
            border-left-color: var(--accent-success);
        }

        .booking-card.completed {
            border-left-color: var(--text-muted);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 1rem;
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .card-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-fixed {
            background: rgba(245, 158, 11, 0.2);
            color: var(--accent-warning);
        }

        .badge-live {
            background: rgba(16, 185, 129, 0.2);
            color: var(--accent-success);
        }

        .badge-completed {
            background: rgba(107, 114, 128, 0.2);
            color: var(--text-muted);
        }

        .card-info {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            margin-bottom: 1rem;
        }

        .info-row {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .info-row i {
            color: var(--accent-primary);
            width: 20px;
        }

        .info-label {
            font-weight: 500;
            color: var(--text-primary);
        }

        /* List View */
        .list-view {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            overflow: hidden;
        }

        .list-table {
            width: 100%;
            border-collapse: collapse;
        }

        .list-table th {
            background: var(--bg-tertiary);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-primary);
            border-bottom: 1px solid var(--border-color);
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.05em;
        }

        .list-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-secondary);
        }

        .list-table tr:hover {
            background: var(--bg-tertiary);
        }

        .list-table tr:last-child td {
            border-bottom: none;
        }

        .type-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .type-fixed {
            background: rgba(245, 158, 11, 0.2);
            color: var(--accent-warning);
        }

        .type-live {
            background: rgba(16, 185, 129, 0.2);
            color: var(--accent-success);
        }

        .type-completed {
            background: rgba(107, 114, 128, 0.2);
            color: var(--text-muted);
        }

        .no-data {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--text-muted);
        }

        .no-data i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-left: 0;
            }

            .top-header {
                padding: 1rem;
            }

            .header-title {
                font-size: 1.5rem;
            }

            .content {
                padding: 1rem;
            }

            .filter-form {
                grid-template-columns: 1fr;
            }

            .grid-view {
                grid-template-columns: 1fr;
            }

            .list-table th,
            .list-table td {
                padding: 0.75rem;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                    <span class="admin-badge">ADMIN</span>
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="admin.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        All Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-reports.php" class="nav-link">
                        <i class="fas fa-file-download"></i>
                        Download Reports
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        System Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-manage-users.php" class="nav-link">
                        <i class="fas fa-users-cog"></i>
                        Manage Users
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-view.php" class="nav-link active">
                        <i class="fas fa-eye"></i>
                        View Bookings
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">View All Bookings</h1>
                <div class="header-actions">
                    <a href="?logout=true" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                <!-- Filter Section -->
                <div class="filter-section">
                    <h2 class="filter-title">
                        <i class="fas fa-filter"></i>
                        Filter Bookings
                    </h2>
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label class="form-label">Time Slot</label>
                            <select name="filter_time" class="form-select">
                                <option value="">All Times</option>
                                <?php foreach ($time_slots as $slot): ?>
                                    <option value="<?php echo $slot; ?>" <?php if ($filter_time === $slot) echo 'selected'; ?>>
                                        <?php echo $slot; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Block</label>
                            <select name="filter_block" class="form-select">
                                <option value="">All Blocks</option>
                                <?php foreach ($blocks as $block): ?>
                                    <option value="<?php echo $block; ?>" <?php if ($filter_block === $block) echo 'selected'; ?>>
                                        Block <?php echo $block; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Lab Name</label>
                            <select name="filter_lab" class="form-select">
                                <option value="">All Labs</option>
                                <?php foreach ($labs as $lab): ?>
                                    <option value="<?php echo $lab; ?>" <?php if ($filter_lab === $lab) echo 'selected'; ?>>
                                        <?php echo $lab; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Min Capacity</label>
                            <select name="filter_capacity" class="form-select">
                                <option value="">Any Capacity</option>
                                <?php foreach ($capacities as $cap): ?>
                                    <option value="<?php echo $cap; ?>" <?php if ($filter_capacity == $cap) echo 'selected'; ?>>
                                        <?php echo $cap; ?>+ Seats
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="filter-buttons">
                            <button type="submit" class="search-btn">
                                <i class="fas fa-search"></i>
                                Search
                            </button>
                            <a href="admin-view.php" class="reset-btn">
                                <i class="fas fa-redo"></i>
                                Reset
                            </a>
                        </div>
                    </form>
                </div>

                <!-- View Mode Toggle -->
                <div class="view-toggle">
                    <a href="?filter_time=<?php echo $filter_time; ?>&filter_block=<?php echo $filter_block; ?>&filter_lab=<?php echo $filter_lab; ?>&filter_capacity=<?php echo $filter_capacity; ?>&filter_status=<?php echo $filter_status; ?>&view_mode=grid" class="toggle-btn <?php if ($view_mode === 'grid') echo 'active'; ?>">
                        <i class="fas fa-th"></i>
                        Grid View
                    </a>
                    <a href="?filter_time=<?php echo $filter_time; ?>&filter_block=<?php echo $filter_block; ?>&filter_lab=<?php echo $filter_lab; ?>&filter_capacity=<?php echo $filter_capacity; ?>&filter_status=<?php echo $filter_status; ?>&view_mode=list" class="toggle-btn <?php if ($view_mode === 'list') echo 'active'; ?>">
                        <i class="fas fa-list"></i>
                        List View
                    </a>
                </div>

                <!-- Status Tabs -->
                <div class="status-tabs">
                    <a href="?filter_time=<?php echo $filter_time; ?>&filter_block=<?php echo $filter_block; ?>&filter_lab=<?php echo $filter_lab; ?>&filter_capacity=<?php echo $filter_capacity; ?>&filter_status=all&view_mode=<?php echo $view_mode; ?>" class="status-tab <?php if ($filter_status === 'all') echo 'active'; ?>">
                        <i class="fas fa-list"></i>
                        All Bookings
                    </a>
                    <a href="?filter_time=<?php echo $filter_time; ?>&filter_block=<?php echo $filter_block; ?>&filter_lab=<?php echo $filter_lab; ?>&filter_capacity=<?php echo $filter_capacity; ?>&filter_status=fixed&view_mode=<?php echo $view_mode; ?>" class="status-tab <?php if ($filter_status === 'fixed') echo 'active'; ?>">
                        <i class="fas fa-calendar-alt"></i>
                        Fixed Timetable
                    </a>
                    <a href="?filter_time=<?php echo $filter_time; ?>&filter_block=<?php echo $filter_block; ?>&filter_lab=<?php echo $filter_lab; ?>&filter_capacity=<?php echo $filter_capacity; ?>&filter_status=live&view_mode=<?php echo $view_mode; ?>" class="status-tab <?php if ($filter_status === 'live') echo 'active'; ?>">
                        <i class="fas fa-broadcast-tower"></i>
                        Live Now
                    </a>
                    <a href="?filter_time=<?php echo $filter_time; ?>&filter_block=<?php echo $filter_block; ?>&filter_lab=<?php echo $filter_lab; ?>&filter_capacity=<?php echo $filter_capacity; ?>&filter_status=completed&view_mode=<?php echo $view_mode; ?>" class="status-tab <?php if ($filter_status === 'completed') echo 'active'; ?>">
                        <i class="fas fa-check-circle"></i>
                        Completed
                    </a>
                </div>

                <!-- Content Display -->
                <?php
                $display_data = [];
                $display_type = '';

                switch ($filter_status) {
                    case 'fixed':
                        $display_data = $fixed_bookings;
                        $display_type = 'fixed';
                        break;
                    case 'live':
                        $display_data = $live_bookings;
                        $display_type = 'live';
                        break;
                    case 'completed':
                        $display_data = $completed_bookings;
                        $display_type = 'completed';
                        break;
                    case 'all':
                    default:
                        $display_data = array_merge($fixed_bookings, $live_bookings, $all_bookings);
                        $display_type = 'all';
                        break;
                }

                if ($view_mode === 'grid'):
                    // Grid View
                    if (count($display_data) > 0):
                        ?>
                        <div class="grid-view">
                            <?php foreach ($display_data as $booking): ?>
                                <div class="booking-card <?php echo $booking['type']; ?>">
                                    <div class="card-header">
                                        <div class="card-title"><?php echo htmlspecialchars($booking['lab']); ?></div>
                                        <span class="card-badge badge-<?php echo $booking['type']; ?>">
                                            <?php echo ucfirst($booking['type']); ?>
                                        </span>
                                    </div>

                                    <div class="card-info">
                                        <div class="info-row">
                                            <i class="fas fa-cube"></i>
                                            <span><span class="info-label">Block:</span> <?php echo htmlspecialchars($booking['block']); ?></span>
                                        </div>

                                        <div class="info-row">
                                            <i class="fas fa-calendar"></i>
                                            <span><span class="info-label">Day:</span> <?php echo htmlspecialchars($booking['day']); ?></span>
                                        </div>

                                        <div class="info-row">
                                            <i class="fas fa-clock"></i>
                                            <span><span class="info-label">Time:</span> <?php echo $booking['start_time']; ?> - <?php echo $booking['end_time']; ?></span>
                                        </div>

                                        <?php if ($booking['type'] === 'fixed'): ?>
                                            <div class="info-row">
                                                <i class="fas fa-book"></i>
                                                <span><span class="info-label">Course:</span> <?php echo htmlspecialchars($booking['course']); ?></span>
                                            </div>

                                            <div class="info-row">
                                                <i class="fas fa-users"></i>
                                                <span><span class="info-label">Capacity:</span> <?php echo $booking['capacity']; ?> Students</span>
                                            </div>
                                        <?php else: ?>
                                            <div class="info-row">
                                                <i class="fas fa-user"></i>
                                                <span><span class="info-label">Booked By:</span> <?php echo htmlspecialchars($booking['username']); ?></span>
                                            </div>

                                            <div class="info-row">
                                                <i class="fas fa-phone"></i>
                                                <span><span class="info-label">Phone:</span> <?php echo htmlspecialchars($booking['phone']); ?></span>
                                            </div>

                                            <div class="info-row">
                                                <i class="fas fa-comment"></i>
                                                <span><span class="info-label">Reason:</span> <?php echo htmlspecialchars($booking['reason']); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="no-data">
                            <i class="fas fa-inbox"></i>
                            <h3>No Bookings Found</h3>
                            <p>No bookings match your current filters.</p>
                        </div>
                    <?php endif;
                else:
                    // List View
                    if (count($display_data) > 0):
                        ?>
                        <div class="list-view">
                            <table class="list-table">
                                <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>Lab</th>
                                        <th>Block</th>
                                        <th>Day</th>
                                        <th>Time</th>
                                        <?php if ($display_type === 'fixed'): ?>
                                            <th>Course</th>
                                            <th>Capacity</th>
                                        <?php else: ?>
                                            <th>Booked By</th>
                                            <th>Phone</th>
                                            <th>Reason</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($display_data as $booking): ?>
                                        <tr>
                                            <td>
                                                <span class="type-badge type-<?php echo $booking['type']; ?>">
                                                    <?php echo ucfirst($booking['type']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo htmlspecialchars($booking['lab']); ?></td>
                                            <td><?php echo htmlspecialchars($booking['block']); ?></td>
                                            <td><?php echo htmlspecialchars($booking['day']); ?></td>
                                            <td><?php echo $booking['start_time']; ?> - <?php echo $booking['end_time']; ?></td>
                                            <?php if ($display_type === 'fixed'): ?>
                                                <td><?php echo htmlspecialchars($booking['course']); ?></td>
                                                <td><?php echo $booking['capacity']; ?> Students</td>
                                            <?php else: ?>
                                                <td><?php echo htmlspecialchars($booking['username']); ?></td>
                                                <td><?php echo htmlspecialchars($booking['phone']); ?></td>
                                                <td><?php echo htmlspecialchars($booking['reason']); ?></td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="no-data">
                            <i class="fas fa-inbox"></i>
                            <h3>No Bookings Found</h3>
                            <p>No bookings match your current filters.</p>
                        </div>
                    <?php endif;
                endif;
                ?>
            </div>
        </main>
    </div>
</body>
</html>
<?php $conn->close(); ?>
