<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Admin Authentication Check
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin_user') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';
$message_type = '';

// Handle POST requests for updating or deleting a user
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle User Deletion
    if (isset($_POST['delete_user'])) {
        $user_id = (int)$_POST['user_id'];
        // Prevent admin from deleting their own account
        if ($user_id > 1) { // Assuming admin user has id=1 or is not in this table
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            if ($stmt->execute()) {
                $message = "User account has been permanently deleted.";
                $message_type = "success";
            } else {
                $message = "Error deleting user: " . $conn->error;
                $message_type = "error";
            }
            $stmt->close();
        } else {
            $message = "Cannot delete the primary admin account.";
            $message_type = "error";
        }
    }

    // Handle User Update
    if (isset($_POST['update_user'])) {
        $user_id = (int)$_POST['user_id'];
        $username = $conn->real_escape_string($_POST['username']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $department = $conn->real_escape_string($_POST['department']);

        $stmt = $conn->prepare("UPDATE users SET username = ?, phone = ?, department = ? WHERE id = ?");
        $stmt->bind_param("sssi", $username, $phone, $department, $user_id);
        if ($stmt->execute()) {
            $message = "User details updated successfully.";
            $message_type = "success";
        } else {
            $message = "Error updating user: " . $conn->error;
            $message_type = "error";
        }
        $stmt->close();
    }
}


// Fetch all users except the admin for display
$users_result = $conn->query("SELECT id, username, phone, department FROM users WHERE username != 'admin_user' ORDER BY username ASC");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Manage Users - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .admin-badge {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
        }

        .card-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .card-title i {
            color: var(--accent-primary);
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
        }

        .alert.success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: var(--accent-success);
        }

        .alert.error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--accent-danger);
        }

        /* Users Table */
        .users-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--bg-tertiary);
            border-radius: 12px;
            overflow: hidden;
        }

        .users-table th,
        .users-table td {
            padding: 1rem 1.5rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .users-table th {
            background: var(--bg-secondary);
            font-weight: 600;
            color: var(--text-primary);
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.05em;
        }

        .users-table td {
            color: var(--text-secondary);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-avatar {
            width: 2.5rem;
            height: 2.5rem;
            background: var(--accent-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
            flex-shrink: 0;
        }
        
        .user-name {
            font-weight: 500;
            color: var(--text-primary);
        }

        .actions {
            display: flex;
            gap: 0.75rem;
        }

        .action-btn {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 0.5rem 1rem;
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .action-btn.edit:hover {
            background: var(--accent-primary);
            color: white;
        }

        .action-btn.delete:hover {
            background: var(--accent-danger);
            color: white;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.8);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: var(--bg-card);
            margin: 10% auto;
            padding: 2rem;
            border: 1px solid var(--border-color);
            width: 90%;
            max-width: 500px;
            border-radius: 20px;
            position: relative;
        }

        .close-btn {
            color: var(--text-muted);
            position: absolute;
            top: 1rem;
            right: 1.5rem;
            font-size: 2rem;
            font-weight: bold;
            cursor: pointer;
        }

        .close-btn:hover {
            color: var(--accent-danger);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .form-input {
            width: 100%;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 1rem;
        }
        
        .form-btn {
            width: 100%;
            padding: 0.75rem;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .form-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                    <span class="admin-badge">ADMIN</span>
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="admin.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                 <div class="nav-item">
                    <a href="admin-reports.php" class="nav-link">
                        <i class="fas fa-file-download"></i>
                        Download Reports
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        All Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        System Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-manage-users.php" class="nav-link active">
                        <i class="fas fa-users-cog"></i>
                        Manage Users
                    </a>
                </div>
                
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">Manage Users</h1>
                <div class="header-actions">
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                 <?php if ($message): ?>
                    <div class="alert <?php echo $message_type; ?>">
                        <i class="fas <?php echo $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'; ?>"></i>
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <h2 class="card-title">
                        <i class="fas fa-users"></i>
                        Registered Lecturers
                    </h2>
                    <div class="users-table-container">
                        <table class="users-table">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Contact</th>
                                    <th>Department</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($users_result && $users_result->num_rows > 0): ?>
                                    <?php while ($user = $users_result->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <div class="user-info">
                                                    <div class="user-avatar"><?php echo strtoupper(substr($user['username'], 0, 1)); ?></div>
                                                    <span class="user-name"><?php echo htmlspecialchars($user['username']); ?></span>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($user['phone'] ?: 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($user['department'] ?: 'N/A'); ?></td>
                                            <td>
                                                <div class="actions">
                                                    <button class="action-btn edit" onclick="openEditModal(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($user['phone'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($user['department'], ENT_QUOTES); ?>')">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </button>
                                                    <form method="POST" onsubmit="return confirm('Are you sure you want to permanently delete this user? This action cannot be undone.');" style="display: inline;">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                        <button type="submit" name="delete_user" class="action-btn delete">
                                                            <i class="fas fa-trash"></i> Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 2rem;">No registered lecturers found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Edit User Modal -->
    <div id="editUserModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeEditModal()">&times;</span>
            <h2 class="card-title"><i class="fas fa-user-edit"></i> Edit User Details</h2>
            <form method="POST">
                <input type="hidden" name="user_id" id="edit-user-id">
                <div class="form-group">
                    <label for="edit-username" class="form-label">Username</label>
                    <input type="text" name="username" id="edit-username" class="form-input" required>
                </div>
                <div class="form-group">
                    <label for="edit-phone" class="form-label">Phone</label>
                    <input type="text" name="phone" id="edit-phone" class="form-input">
                </div>
                <div class="form-group">
                    <label for="edit-department" class="form-label">Department</label>
                    <input type="text" name="department" id="edit-department" class="form-input" required>
                </div>
                <button type="submit" name="update_user" class="form-btn">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('editUserModal');

        function openEditModal(id, username, phone, department) {
            document.getElementById('edit-user-id').value = id;
            document.getElementById('edit-username').value = username;
            document.getElementById('edit-phone').value = phone;
            document.getElementById('edit-department').value = department;
            modal.style.display = 'block';
        }

        function closeEditModal() {
            modal.style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                closeEditModal();
            }
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>
