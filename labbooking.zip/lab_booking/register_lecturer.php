<?php
// register_lecturer.php

session_start();
date_default_timezone_set('Asia/Kolkata');

// Define the Secret Key
$secret_key = 'Vvce@123'; // This is your secret key

// Database Connection
$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = ''; // To store success or error messages
$show_registration_form = false; // Flag to control which form is shown

// Step 1: Check if a secret key was submitted
if (isset($_POST['submit_key'])) {
    if (!empty($_POST['secret_key']) && $_POST['secret_key'] === $secret_key) {
        // If key is correct, set a session variable and show the registration form
        $_SESSION['key_validated'] = true;
        $show_registration_form = true;
    } else {
        $message = "<div class='message error'>Invalid secret key. Access denied.</div>";
    }
}

// Check if the key has already been validated in the current session
if (isset($_SESSION['key_validated']) && $_SESSION['key_validated'] === true) {
    $show_registration_form = true;
}

// Step 2: Handle the actual registration form submission
if (isset($_POST['register_lecturer'])) {
    // Ensure the key was validated before processing registration
    if ($show_registration_form) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        $phone = trim($_POST['phone']);
        $department = trim($_POST['department']);
        $errors = []; // Use an array to collect all errors

        // ==================================================================
        // == FIX: Improved validation logic to check all fields at once   ==
        // ==================================================================

        // 1. Username format validation
        if (!preg_match('/^[a-zA-Z][a-zA-Z\s.]*$/', $username)) {
            $errors[] = "Invalid username. It must be a name and cannot start with numbers or contain invalid special characters.";
        }

        // 2. Check if username already exists
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt_check->bind_param("s", $username);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows > 0) {
            $errors[] = "This username already exists. Please choose a different one.";
        }
        $stmt_check->close();

        // 3. Password validation
        if (empty($password)) {
            $errors[] = "Password cannot be empty.";
        } elseif (strlen($password) < 6) {
            $errors[] = "Password must be at least 6 characters long.";
        }
        
        // 4. Department validation
        if (empty($department)) {
            $errors[] = "Department cannot be empty.";
        }

        // If there are any errors, combine them and display.
        if (!empty($errors)) {
            $message = "<div class='message error'>" . implode('<br>', $errors) . "</div>";
        } else {
            // Insert into Database if no errors
            $stmt_insert = $conn->prepare("INSERT INTO users (username, password, phone, department) VALUES (?, ?, ?, ?)");
            $stmt_insert->bind_param("ssss", $username, $password, $phone, $department);
            
            if ($stmt_insert->execute()) {
                $message = "<div class='message success'>Lecturer '$username' registered successfully! They can now log in.</div>";
                // Unset the session key so they have to re-enter it next time
                unset($_SESSION['key_validated']);
                $show_registration_form = false; // Hide form after successful registration
            } else {
                $message = "<div class='message error'>Error: Could not register user.</div>";
            }
            $stmt_insert->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Lecturer - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .register-container {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 3rem;
            width: 100%;
            max-width: 500px;
            box-shadow: var(--shadow-lg);
        }

        .header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
        }

        .header h1 i {
            color: var(--accent-primary);
        }

        .header p {
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--accent-primary);
            text-decoration: none;
            font-weight: 500;
            margin-bottom: 2rem;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: var(--accent-secondary);
        }

        .message {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
        }

        .message.success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: var(--accent-success);
        }

        .message.error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--accent-danger);
        }

        .form-section {
            margin-bottom: 2rem;
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title i {
            color: var(--accent-primary);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .form-input {
            width: 100%;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-input::placeholder {
            color: var(--text-muted);
        }

        .form-btn {
            width: 100%;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            font-size: 1rem;
        }

        .form-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .form-btn.success {
            background: linear-gradient(135deg, var(--accent-success), #059669);
        }

        .security-notice {
            background: rgba(245, 158, 11, 0.1);
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 2rem;
        }

        .security-title {
            color: var(--accent-warning);
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .security-text {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .key-form {
            text-align: center;
        }

        .key-icon {
            width: 4rem;
            height: 4rem;
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 1.5rem;
            color: white;
        }

        .success-icon {
            width: 4rem;
            height: 4rem;
            background: linear-gradient(135deg, var(--accent-success), #059669);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 1.5rem;
            color: white;
        }

        .success-message {
            text-align: center;
            padding: 2rem;
        }

        .success-message h3 {
            color: var(--text-primary);
            margin-bottom: 1rem;
        }

        .success-message p {
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }

        .login-link {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            padding: 0.75rem 2rem;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .login-link:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 1rem;
            }

            .register-container {
                padding: 2rem;
            }

            .header h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="header">
            <h1>
                <i class="fas fa-user-plus"></i>
                Register New Lecturer
            </h1>
            <p>Add a new lecturer to the lab booking system</p>
        </div>

        <a href="login.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
            Back to Login
        </a>

        <?php echo $message; // Display success or error message here ?>

        <?php if ($show_registration_form): ?>
            <!-- Registration Form -->
            <div class="form-section">
                <div class="section-title">
                    <i class="fas fa-user-edit"></i>
                    Lecturer Information
                </div>
                <form method="POST">
                    <input type="hidden" name="register_lecturer" value="1">
                    
                    <div class="form-group">
                        <label class="form-label">Lecturer Name (Username)</label>
                        <input type="text" name="username" class="form-input" placeholder="Enter full name" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-input" placeholder="Create a secure password" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Phone Number</label>
                        <input type="text" name="phone" class="form-input" placeholder="Enter phone number (optional)">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Department</label>
                        <input type="text" name="department" class="form-input" placeholder="Enter department name" required>
                    </div>

                    <button type="submit" class="form-btn success">
                        <i class="fas fa-user-plus"></i>
                        Register Lecturer
                    </button>
                </form>
            </div>
        <?php elseif (!empty($message) && strpos($message, 'successfully') !== false): ?>
            <!-- Success State -->
            <div class="success-message">
                <div class="success-icon">
                    <i class="fas fa-check"></i>
                </div>
                <h3>Registration Successful!</h3>
                <p>The lecturer has been successfully registered and can now log in to the system.</p>
                <a href="login.php" class="login-link">
                    <i class="fas fa-sign-in-alt"></i>
                    Go to Login
                </a>
            </div>
        <?php else: ?>
            <!-- Secret Key Form -->
            <div class="security-notice">
                <div class="security-title">
                    <i class="fas fa-shield-alt"></i>
                    Admin Access Required
                </div>
                <div class="security-text">
                    This area is restricted to administrators only. Please enter the secret key to proceed with lecturer registration.
                </div>
            </div>

            <div class="key-form">
                <div class="key-icon">
                    <i class="fas fa-key"></i>
                </div>
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Secret Key</label>
                        <input type="password" name="secret_key" class="form-input" placeholder="Enter the secret key" required>
                    </div>
                    <button type="submit" name="submit_key" class="form-btn">
                        <i class="fas fa-unlock"></i>
                        Verify Access
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
