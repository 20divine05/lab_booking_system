<?php
// Start the session at the very beginning of the script.
session_start();

// Check if the form has been submitted using the POST method.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve username and password from the submitted form data.
    $username = $_POST['username'];
    $password = $_POST['password'];

    // --- Admin Login Check ---
    // First, check for the hardcoded admin credentials.
    // This provides a separate, direct entry point for the site administrator.
    if ($username === 'admin' && $password === 'admin123') {
        // If credentials match, set a specific session variable for the admin.
        $_SESSION['username'] = 'admin_user';
        // Redirect the admin to their dedicated dashboard.
        header("Location: admin.php");
        exit; // Stop script execution after redirect.
    }

    // --- Regular User Login ---
    // If it's not an admin, proceed with database connection for regular users.
    $conn = new mysqli('localhost', 'root', '', 'lab_booking');

    // Check for any connection errors.
    if ($conn->connect_error) {
        die('Connection Failed: ' . $conn->connect_error);
    }

    // Use a prepared statement to prevent SQL injection. This is a crucial security practice.
    // The '?' is a placeholder for the username.
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    // Bind the user-provided username to the placeholder. 's' specifies the type is a string.
    $stmt->bind_param('s', $username);
    // Execute the prepared statement.
    $stmt->execute();
    // Get the result of the query.
    $result = $stmt->get_result();

    // Check if a user with the given username was found (if number of rows is greater than 0).
    if ($result->num_rows > 0) {
        // Fetch the user's data as an associative array.
        $user_data = $result->fetch_assoc();
        
        // --- IMPORTANT ---
        // Your original file compared plain text passwords. We are replicating that here.
        if ($password === $user_data['password']) {
            // If the password is correct, store the username in the session.
            $_SESSION['username'] = $user_data['username'];
            // Redirect the user to the main booking page.
            header("Location: index.php");
            exit; // Stop script execution.
        } else {
            // If the password is incorrect, set an error message.
            $error = "Invalid password.";
        }
    } else {
        // If no user was found with that username, set an error message.
        $error = "Invalid username.";
    }

    // Close the statement and the database connection.
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.6);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, var(--bg-primary) 0%, var(--bg-secondary) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-primary);
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="%23ffffff" stroke-width="0.5" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
            opacity: 0.3;
        }

        .login-container {
            background: rgba(22, 33, 62, 0.9);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 3rem;
            width: 100%;
            max-width: 450px;
            box-shadow: var(--shadow-lg);
            position: relative;
            z-index: 1;
        }

        .logo-section {
            text-align: center;
            margin-bottom: 2.5rem;
        }

        .logo {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 2rem;
        }

        .subtitle {
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .input-wrapper {
            position: relative;
        }

        .form-input {
            width: 100%;
            padding: 1rem 1rem 1rem 3rem;
            background: rgba(45, 55, 72, 0.5);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
            background: rgba(45, 55, 72, 0.8);
        }

        .form-input::placeholder {
            color: var(--text-secondary);
        }

        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
            font-size: 1.1rem;
        }

        .login-btn {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0, 212, 255, 0.3);
        }

        .error-message {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--accent-danger);
            padding: 1rem;
            border-radius: 12px;
            text-align: center;
            font-weight: 500;
            margin-bottom: 1.5rem;
        }

        .info-section {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1rem;
        }

        .info-title {
            color: var(--accent-success);
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .info-text {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .register-link {
            text-align: center;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .register-link a {
            color: var(--accent-primary);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .register-link a:hover {
            color: var(--accent-secondary);
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 2rem;
                margin: 1rem;
            }

            .logo {
                font-size: 1.5rem;
            }

            .logo i {
                font-size: 1.75rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo-section">
            <div class="logo">
                <i class="fas fa-flask"></i>
                Lab Booking System
            </div>
            <p class="subtitle">Secure access to laboratory resources</p>
        </div>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label class="form-label" for="username">Username</label>
                <div class="input-wrapper">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" id="username" name="username" class="form-input" placeholder="Enter your username" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" id="password" name="password" class="form-input" placeholder="Enter your password" required>
                </div>
            </div>

            <button type="submit" class="login-btn">
                <i class="fas fa-sign-in-alt" style="margin-right: 0.5rem;"></i>
                Sign In
            </button>
        </form>

        <?php 
        if (isset($error)) {
            echo "<div class='error-message'><i class='fas fa-exclamation-triangle' style='margin-right: 0.5rem;'></i>$error</div>";
        } 
        ?>
        
        <div class="info-section">
            <div class="info-title">
                <i class="fas fa-info-circle"></i>
                Admin Access
            </div>
            <div class="info-text">
                Use <strong>admin / admin123</strong> for administrative access
            </div>
        </div>
        
        <div class="register-link">
            Admin? <a href="register_lecturer.php">Register a new lecturer here</a>
        </div>
    </div>
</body>
</html>
