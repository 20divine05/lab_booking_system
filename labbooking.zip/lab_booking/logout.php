<?php
// 1. Start the session.
// This is necessary to access and manipulate the current session.
session_start();

// 2. Unset all of the session variables.
// This removes all data stored in the session, such as $_SESSION['username'].
session_unset();

// 3. Destroy the session.
// This completely removes the session from the server.
session_destroy();

// 4. Redirect to the login page.
// After the session is terminated, the user is sent back to the login screen.
header("Location: login.php");

// 5. Exit the script.
// It's good practice to call exit() after a header redirect to ensure no further code is executed.
exit;
?>
