<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Admin Authentication Check
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin_user') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';
$message_type = '';

// Handle system maintenance actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['clear_old_bookings'])) {
        $days = (int)$_POST['days_old'];
        $cutoff_date = date('Y-m-d', strtotime("-$days days"));
        
        $result = $conn->query("DELETE FROM booked_labs WHERE booking_date < '$cutoff_date'");
        if ($result) {
            $affected = $conn->affected_rows;
            $message = "Successfully cleared $affected old booking records older than $days days.";
            $message_type = "success";
        } else {
            $message = "Error clearing old bookings: " . $conn->error;
            $message_type = "error";
        }
    }
    
    if (isset($_POST['clear_cancelled_bookings'])) {
        $days = (int)$_POST['cancelled_days_old'];
        $cutoff_date = date('Y-m-d', strtotime("-$days days"));
        
        $result = $conn->query("DELETE FROM deleted_bookings WHERE deleted_at < '$cutoff_date'");
        if ($result) {
            $affected = $conn->affected_rows;
            $message = "Successfully cleared $affected cancelled booking records older than $days days.";
            $message_type = "success";
        } else {
            $message = "Error clearing cancelled bookings: " . $conn->error;
            $message_type = "error";
        }
    }
}

// Get system statistics
$total_labs = $conn->query("SELECT COUNT(*) as count FROM labs")->fetch_assoc()['count'];
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$total_bookings = $conn->query("SELECT COUNT(*) as count FROM booked_labs")->fetch_assoc()['count'];
$active_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings")->fetch_assoc()['count'];
$cancelled_bookings = $conn->query("SELECT COUNT(*) as count FROM deleted_bookings")->fetch_assoc()['count'];

// Get database size information (approximate)
$db_size_result = $conn->query("SELECT 
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'DB Size in MB' 
    FROM information_schema.tables 
    WHERE table_schema='lab_booking'");
$db_size = $db_size_result ? $db_size_result->fetch_assoc()['DB Size in MB'] : 'Unknown';

// Get recent activity count
$recent_activity = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_date >= DATE_SUB(NOW(), INTERVAL 7 DAYS)")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin System Settings - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .admin-badge {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .header-title .admin-indicator {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Alert Messages */
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
        }

        .alert.success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: var(--accent-success);
        }

        .alert.error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--accent-danger);
        }

        /* Settings Grid */
        .settings-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .settings-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .settings-card:hover {
            box-shadow: var(--shadow-lg);
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .card-title i {
            color: var(--accent-primary);
        }

        /* System Overview */
        .system-overview {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .overview-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }

        .overview-item {
            text-align: center;
            padding: 1.5rem;
            background: var(--bg-tertiary);
            border-radius: 12px;
            border: 1px solid var(--border-color);
        }

        .overview-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent-primary);
            margin-bottom: 0.5rem;
        }

        .overview-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .form-input,
        .form-select {
            width: 100%;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-input:focus,
        .form-select:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-input::placeholder {
            color: var(--text-muted);
        }

        .form-btn {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            width: 100%;
        }

        .form-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .form-btn.danger {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
        }

        .form-btn.warning {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
        }

        /* Warning Box */
        .warning-box {
            background: rgba(245, 158, 11, 0.1);
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1.5rem;
        }

        .warning-title {
            color: var(--accent-warning);
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .warning-text {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .settings-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-left: 0;
            }

            .top-header {
                padding: 1rem;
            }

            .header-title {
                font-size: 1.5rem;
            }

            .content {
                padding: 1rem;
            }

            .overview-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                    <span class="admin-badge">ADMIN</span>
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="admin.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        All Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        System Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-settings.php" class="nav-link active">
                        <i class="fas fa-cog"></i>
                        System Settings
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">
                    System Settings
                    <span class="admin-indicator">
                        <i class="fas fa-crown"></i>
                        Administrator
                    </span>
                </h1>
                <div class="header-actions">
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                <!-- Alert Messages -->
                <?php if ($message): ?>
                    <div class="alert <?php echo $message_type; ?>">
                        <i class="fas <?php echo $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'; ?>"></i>
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>

                <!-- System Overview -->
                <div class="system-overview">
                    <h2 class="card-title">
                        <i class="fas fa-server"></i>
                        System Overview
                    </h2>
                    <div class="overview-grid">
                        <div class="overview-item">
                            <div class="overview-value"><?php echo $total_labs; ?></div>
                            <div class="overview-label">Total Labs</div>
                        </div>
                        <div class="overview-item">
                            <div class="overview-value"><?php echo $total_users; ?></div>
                            <div class="overview-label">Registered Users</div>
                        </div>
                        <div class="overview-item">
                            <div class="overview-value"><?php echo $total_bookings; ?></div>
                            <div class="overview-label">Total Bookings</div>
                        </div>
                        <div class="overview-item">
                            <div class="overview-value"><?php echo $active_bookings; ?></div>
                            <div class="overview-label">Active Bookings</div>
                        </div>
                        <div class="overview-item">
                            <div class="overview-value"><?php echo $cancelled_bookings; ?></div>
                            <div class="overview-label">Cancelled Bookings</div>
                        </div>
                        <div class="overview-item">
                            <div class="overview-value"><?php echo $db_size; ?> MB</div>
                            <div class="overview-label">Database Size</div>
                        </div>
                        <div class="overview-item">
                            <div class="overview-value"><?php echo $recent_activity; ?></div>
                            <div class="overview-label">This Week's Activity</div>
                        </div>
                    </div>
                </div>

                <!-- Settings Forms -->
                <div class="settings-grid">
                    <!-- Database Maintenance -->
                    <div class="settings-card">
                        <h3 class="card-title">
                            <i class="fas fa-database"></i>
                            Database Maintenance
                        </h3>
                        
                        <div class="warning-box">
                            <div class="warning-title">
                                <i class="fas fa-exclamation-triangle"></i>
                                Caution Required
                            </div>
                            <div class="warning-text">
                                These operations will permanently delete data from the database. Please ensure you have backups before proceeding.
                            </div>
                        </div>

                        <form method="POST" onsubmit="return confirm('Are you sure you want to clear old booking records? This action cannot be undone.');">
                            <div class="form-group">
                                <label class="form-label">Clear Old Booking History</label>
                                <select name="days_old" class="form-select">
                                    <option value="30">Older than 30 days</option>
                                    <option value="60">Older than 60 days</option>
                                    <option value="90">Older than 90 days</option>
                                    <option value="180">Older than 6 months</option>
                                    <option value="365">Older than 1 year</option>
                                </select>
                            </div>
                            <button type="submit" name="clear_old_bookings" class="form-btn warning">
                                <i class="fas fa-trash"></i>
                                Clear Old Bookings
                            </button>
                        </form>

                        <br>

                        <form method="POST" onsubmit="return confirm('Are you sure you want to clear cancelled booking records? This action cannot be undone.');">
                            <div class="form-group">
                                <label class="form-label">Clear Cancelled Bookings</label>
                                <select name="cancelled_days_old" class="form-select">
                                    <option value="7">Older than 7 days</option>
                                    <option value="30">Older than 30 days</option>
                                    <option value="60">Older than 60 days</option>
                                    <option value="90">Older than 90 days</option>
                                </select>
                            </div>
                            <button type="submit" name="clear_cancelled_bookings" class="form-btn danger">
                                <i class="fas fa-trash-alt"></i>
                                Clear Cancelled Records
                            </button>
                        </form>
                    </div>

                    <!-- System Information -->
                    <div class="settings-card">
                        <h3 class="card-title">
                            <i class="fas fa-info-circle"></i>
                            System Information
                        </h3>
                        
                        <div class="form-group">
                            <label class="form-label">System Version</label>
                            <input type="text" class="form-input" value="Lab Booking System v2.0" readonly>
                        </div>

                        <div class="form-group">
                            <label class="form-label">PHP Version</label>
                            <input type="text" class="form-input" value="<?php echo phpversion(); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Server Time</label>
                            <input type="text" class="form-input" value="<?php echo date('Y-m-d H:i:s T'); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Timezone</label>
                            <input type="text" class="form-input" value="<?php echo date_default_timezone_get(); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Admin Session</label>
                            <input type="text" class="form-input" value="Active since login" readonly>
                        </div>

                        <a href="admin_full_access.php" class="form-btn">
                            <i class="fas fa-th"></i>
                            Access Full Grid View
                        </a>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="settings-card">
                    <h3 class="card-title">
                        <i class="fas fa-bolt"></i>
                        Quick Actions
                    </h3>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                        <a href="register_lecturer.php" class="form-btn">
                            <i class="fas fa-user-plus"></i>
                            Add New Lecturer
                        </a>
                        
                        <a href="admin_full_access.php" class="form-btn">
                            <i class="fas fa-calendar-alt"></i>
                            Manage All Bookings
                        </a>
                        
                        <button onclick="window.print()" class="form-btn">
                            <i class="fas fa-print"></i>
                            Print System Report
                        </button>
                        
                        <button onclick="exportData()" class="form-btn">
                            <i class="fas fa-download"></i>
                            Export Data
                        </button>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function exportData() {
            alert('Export functionality would be implemented here. This could generate CSV/Excel files with system data.');
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>
