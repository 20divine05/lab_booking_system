<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// ============================================================================
// == UPDATED: Queries now correctly differentiate booking states            ==
// ============================================================================
$user_stats = [
    'total_bookings' => 0,
    'active_bookings' => 0,
    'completed_bookings' => 0,
    'cancelled_bookings' => 0
];

// This correctly counts all historical bookings from the history table
$total_result = $conn->query("SELECT COUNT(*) as count FROM booked_labs WHERE username='$username'");
if ($total_result) {
    $user_stats['total_bookings'] = $total_result->fetch_assoc()['count'];
    $user_stats['completed_bookings'] = $user_stats['total_bookings']; // Completed is the same as total history
}

// This now correctly counts only active (non-deleted) bookings
$active_result = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE username='$username' AND deleted=0");
if ($active_result) {
    $user_stats['active_bookings'] = $active_result->fetch_assoc()['count'];
}

// This correctly counts from the deleted bookings archive
$cancelled_result = $conn->query("SELECT COUNT(*) as count FROM deleted_bookings WHERE username='$username'");
if ($cancelled_result) {
    $user_stats['cancelled_bookings'] = $cancelled_result->fetch_assoc()['count'];
}

// The rest of the queries below are already correct as they use the 'booked_labs' table for patterns.
// No changes are needed for them.

// Get booking patterns by day
$day_pattern = [];
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
foreach ($days as $day) {
    $result = $conn->query("SELECT COUNT(*) as count FROM booked_labs WHERE username='$username' AND day='$day'");
    $day_pattern[$day] = $result ? $result->fetch_assoc()['count'] : 0;
}

// Get booking patterns by time
$time_pattern = [];
$time_slots = ['08:30-10:30', '11:00-13:00', '14:00-16:00', '16:00-17:00'];
foreach ($time_slots as $slot) {
    list($start, $end) = explode('-', $slot);
    $result = $conn->query("SELECT COUNT(*) as count FROM booked_labs WHERE username='$username' AND start_time='$start'");
    $time_pattern[$slot] = $result ? $result->fetch_assoc()['count'] : 0;
}

// Get favorite labs
$favorite_labs = [];
$fav_result = $conn->query("SELECT lab, COUNT(*) as count FROM booked_labs WHERE username='$username' GROUP BY lab ORDER BY count DESC LIMIT 5");
if ($fav_result && $fav_result->num_rows > 0) {
    while ($row = $fav_result->fetch_assoc()) {
        $favorite_labs[] = $row;
    }
}

// Get recent activity
$recent_activity = [];
$recent_result = $conn->query("SELECT lab, day, start_time, end_time, booking_date, 'booked' as action FROM booked_labs WHERE username='$username' 
                               UNION ALL 
                               SELECT lab, day, start_time, end_time, deleted_at as booking_date, 'cancelled' as action FROM deleted_bookings WHERE username='$username' 
                               ORDER BY booking_date DESC LIMIT 10");
if ($recent_result && $recent_result->num_rows > 0) {
    while ($row = $recent_result->fetch_assoc()) {
        $recent_activity[] = $row;
    }
}

// Get top users (for comparison)
$top_users = [];
$top_result = $conn->query("SELECT username, COUNT(*) as count FROM booked_labs GROUP BY username ORDER BY count DESC LIMIT 5");
if ($top_result && $top_result->num_rows > 0) {
    while ($row = $top_result->fetch_assoc()) {
        $top_users[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-tertiary);
            border-radius: 12px;
            border: 1px solid var(--border-color);
        }

        .user-avatar {
            width: 2.5rem;
            height: 2.5rem;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card.blue {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
        }

        .stat-card.green {
            background: linear-gradient(135deg, #10b981, #059669);
        }

        .stat-card.yellow {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }

        .stat-card.red {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }

        .stat-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.9rem;
            font-weight: 500;
        }

        .stat-icon {
            width: 3rem;
            height: 3rem;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: white;
            margin-bottom: 0.5rem;
        }

        .stat-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.85rem;
        }

        /* Charts Grid */
        .charts-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .chart-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .chart-card:hover {
            box-shadow: var(--shadow-lg);
        }

        .chart-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .chart-title i {
            color: var(--accent-primary);
        }

        .chart-container {
            position: relative;
            height: 300px;
        }

        /* Activity Grid */
        .activity-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .card:hover {
            box-shadow: var(--shadow-lg);
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .card-title i {
            color: var(--accent-primary);
        }

        /* Activity Timeline */
        .activity-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 2.5rem;
            height: 2.5rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.9rem;
            flex-shrink: 0;
        }

        .activity-icon.booked {
            background: var(--accent-success);
        }

        .activity-icon.cancelled {
            background: var(--accent-danger);
        }

        .activity-details {
            flex: 1;
        }

        .activity-title {
            color: var(--text-primary);
            font-weight: 500;
            margin-bottom: 0.25rem;
        }

        .activity-meta {
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        /* Favorite Labs */
        .lab-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .lab-item:last-child {
            border-bottom: none;
        }

        .lab-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .lab-icon {
            width: 2.5rem;
            height: 2.5rem;
            background: var(--accent-primary);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .lab-name {
            color: var(--text-primary);
            font-weight: 500;
        }

        .lab-count {
            background: var(--bg-tertiary);
            color: var(--accent-primary);
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        /* Top Users */
        .user-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .user-item:last-child {
            border-bottom: none;
        }

        .user-rank {
            width: 2rem;
            height: 2rem;
            background: var(--accent-secondary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            margin-right: 0.75rem;
        }

        .user-name {
            color: var(--text-primary);
            font-weight: 500;
            flex: 1;
        }

        .user-count {
            background: var(--bg-tertiary);
            color: var(--accent-secondary);
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .activity-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-left: 0;
            }

            .top-header {
                padding: 1rem;
            }

            .header-title {
                font-size: 1.5rem;
            }

            .content {
                padding: 1rem;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="index.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="my-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        My Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="analytics.php" class="nav-link active">
                        <i class="fas fa-chart-bar"></i>
                        Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">Analytics</h1>
                <div class="header-actions">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($username, 0, 1)); ?>
                        </div>
                        <span>Hello, <?php echo htmlspecialchars($username); ?></span>
                    </div>
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card blue">
                        <div class="stat-header">
                            <div>
                                <div class="stat-title">Total Bookings</div>
                                <div class="stat-value"><?php echo $user_stats['total_bookings']; ?></div>
                                <div class="stat-subtitle">All time bookings</div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card green">
                        <div class="stat-header">
                            <div>
                                <div class="stat-title">Active Bookings</div>
                                <div class="stat-value"><?php echo $user_stats['active_bookings']; ?></div>
                                <div class="stat-subtitle">Currently active</div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card yellow">
                        <div class="stat-header">
                            <div>
                                <div class="stat-title">Completed</div>
                                <div class="stat-value"><?php echo $user_stats['completed_bookings']; ?></div>
                                <div class="stat-subtitle">Successfully completed</div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card red">
                        <div class="stat-header">
                            <div>
                                <div class="stat-title">Cancelled</div>
                                <div class="stat-value"><?php echo $user_stats['cancelled_bookings']; ?></div>
                                <div class="stat-subtitle">Cancelled bookings</div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-times-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts -->
                <div class="charts-grid">
                    <div class="chart-card">
                        <h3 class="chart-title">
                            <i class="fas fa-calendar-week"></i>
                            Booking Patterns by Day
                        </h3>
                        <div class="chart-container">
                            <canvas id="dayChart"></canvas>
                        </div>
                    </div>

                    <div class="chart-card">
                        <h3 class="chart-title">
                            <i class="fas fa-clock"></i>
                            Booking Patterns by Time
                        </h3>
                        <div class="chart-container">
                            <canvas id="timeChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Activity Grid -->
                <div class="activity-grid">
                    <div class="card">
                        <h3 class="card-title">
                            <i class="fas fa-history"></i>
                            Recent Activity
                        </h3>
                        <?php if (!empty($recent_activity)): ?>
                            <?php foreach ($recent_activity as $activity): ?>
                                <div class="activity-item">
                                    <div class="activity-icon <?php echo $activity['action']; ?>">
                                        <i class="fas <?php echo $activity['action'] == 'booked' ? 'fa-plus' : 'fa-times'; ?>"></i>
                                    </div>
                                    <div class="activity-details">
                                        <div class="activity-title">
                                            <?php echo ucfirst($activity['action']); ?> <?php echo htmlspecialchars($activity['lab']); ?>
                                        </div>
                                        <div class="activity-meta">
                                            <?php echo htmlspecialchars($activity['day']); ?> at <?php echo $activity['start_time']; ?> - <?php echo $activity['end_time']; ?>
                                            • <?php echo date('M d, Y', strtotime($activity['booking_date'])); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="color: var(--text-muted); text-align: center; padding: 2rem;">No recent activity found.</p>
                        <?php endif; ?>
                    </div>

                    <div>
                        <div class="card" style="margin-bottom: 1.5rem;">
                            <h3 class="card-title">
                                <i class="fas fa-star"></i>
                                Your Favorite Labs
                            </h3>
                            <?php if (!empty($favorite_labs)): ?>
                                <?php foreach ($favorite_labs as $lab): ?>
                                    <div class="lab-item">
                                        <div class="lab-info">
                                            <div class="lab-icon">
                                                <?php echo substr($lab['lab'], 0, 1); ?>
                                            </div>
                                            <div class="lab-name"><?php echo htmlspecialchars($lab['lab']); ?></div>
                                        </div>
                                        <div class="lab-count"><?php echo $lab['count']; ?> times</div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="color: var(--text-muted); text-align: center; padding: 1rem;">No booking history yet.</p>
                            <?php endif; ?>
                        </div>

                        <div class="card">
                            <h3 class="card-title">
                                <i class="fas fa-trophy"></i>
                                Top Users
                            </h3>
                            <?php if (!empty($top_users)): ?>
                                <?php foreach ($top_users as $index => $user): ?>
                                    <div class="user-item">
                                        <div style="display: flex; align-items: center;">
                                            <div class="user-rank"><?php echo $index + 1; ?></div>
                                            <div class="user-name <?php echo $user['username'] == $username ? 'style="color: var(--accent-primary);"' : ''; ?>">
                                                <?php echo htmlspecialchars($user['username']); ?>
                                                <?php if ($user['username'] == $username): ?>
                                                    <span style="color: var(--accent-primary); font-size: 0.8rem;">(You)</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="user-count"><?php echo $user['count']; ?> bookings</div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="color: var(--text-muted); text-align: center; padding: 1rem;">No data available.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Day Pattern Chart
        const dayCtx = document.getElementById('dayChart').getContext('2d');
        const dayChart = new Chart(dayCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_keys($day_pattern)); ?>,
                datasets: [{
                    label: 'Bookings',
                    data: <?php echo json_encode(array_values($day_pattern)); ?>,
                    backgroundColor: 'rgba(0, 212, 255, 0.8)',
                    borderColor: 'rgba(0, 212, 255, 1)',
                    borderWidth: 1,
                    borderRadius: 8,
                    borderSkipped: false,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#a0a9c0'
                        },
                        grid: {
                            color: '#2d3748'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#a0a9c0'
                        },
                        grid: {
                            color: '#2d3748'
                        }
                    }
                }
            }
        });

        // Time Pattern Chart
        const timeCtx = document.getElementById('timeChart').getContext('2d');
        const timeChart = new Chart(timeCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_keys($time_pattern)); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_values($time_pattern)); ?>,
                    backgroundColor: [
                        'rgba(0, 212, 255, 0.8)',
                        'rgba(124, 58, 237, 0.8)',
                        'rgba(16, 185, 129, 0.8)',
                        'rgba(245, 158, 11, 0.8)'
                    ],
                    borderColor: [
                        'rgba(0, 212, 255, 1)',
                        'rgba(124, 58, 237, 1)',
                        'rgba(16, 185, 129, 1)',
                        'rgba(245, 158, 11, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#a0a9c0',
                            padding: 20
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>
