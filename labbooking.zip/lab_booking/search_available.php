<?php
// search_available.php

// PHPMailer Integration
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Kolkata');

// Authentication & DB Connection
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'lab_booking');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// Determine the correct back link based on where the user came from
$back_link = 'search-rooms.php'; // Default for regular users
if (isset($_POST['origin']) && $_POST['origin'] === 'admin') {
    $back_link = 'admin-search-rooms.php'; // Change link if search came from admin page
}

/**
 * Checks if a booking slot has already passed based on the full date and end time.
 *
 * @param string $date The date of the booking (e.g., '2024-08-10').
 * @param string $end_time The end time of the slot (e.g., '10:00').
 * @return bool True if the slot has expired, false otherwise.
 */
function is_slot_expired($date, $end_time) {
    // Combine the selected date and the slot's end time to create a full datetime string.
    $slot_datetime_str = $date . ' ' . $end_time;
    
    // Convert the slot's datetime string into a Unix timestamp.
    $slot_timestamp = strtotime($slot_datetime_str);
    
    // Get the current Unix timestamp.
    $current_timestamp = time();
    
    // Return true if the current time is greater than or equal to the slot's end time.
    return $current_timestamp >= $slot_timestamp;
}

/**
 * Converts time string (HH:MM) to minutes since midnight for accurate comparison
 *
 * @param string $time_str Time in HH:MM format
 * @return int Minutes since midnight
 */
function time_to_minutes($time_str) {
    list($hours, $minutes) = explode(':', trim($time_str));
    return (int)$hours * 60 + (int)$minutes;
}

/**
 * Checks if two time slots overlap
 *
 * @param string $search_start Start time of search slot (HH:MM)
 * @param string $search_end End time of search slot (HH:MM)
 * @param string $booking_start Start time of existing booking (HH:MM)
 * @param string $booking_end End time of existing booking (HH:MM)
 * @return bool True if slots overlap, false otherwise
 */
function times_overlap($search_start, $search_end, $booking_start, $booking_end) {
    $search_start_min = time_to_minutes($search_start);
    $search_end_min = time_to_minutes($search_end);
    $booking_start_min = time_to_minutes($booking_start);
    $booking_end_min = time_to_minutes($booking_end);
    
    // Two time slots overlap if: search_start < booking_end AND search_end > booking_start
    return $search_start_min < $booking_end_min && $search_end_min > $booking_start_min;
}

// Handle a new booking request
if (isset($_POST['book_now'])) {
    $block = $_POST['block'];
    $type = $_POST['type'];
    $lab = $_POST['lab'];
    $date = $_POST['date'];
    $day = date('l', strtotime($date));
    $time = $_POST['time'];
    $reason = $conn->real_escape_string($_POST['reason']);
    list($start_time, $end_time) = explode('-', $time);

    if (is_slot_expired($date, $end_time)) {
        echo "<script>alert('This time slot has already passed and cannot be booked.'); window.history.back();</script>";
        exit;
    }

    // Get user's phone number and department for HOD notification
    $user_info_res = $conn->query("SELECT phone, department FROM users WHERE username='$username'");
    $user_info = $user_info_res->fetch_assoc();
    $phone = $user_info['phone'];
    $department = $user_info['department'];

    $check_booked = $conn->query("SELECT * FROM bookings WHERE lab='$lab' AND block='$block' AND DATE(booking_date) = '$date' AND deleted=0");
    $check_booked_labs = $conn->query("SELECT * FROM booked_labs WHERE lab='$lab' AND block='$block' AND DATE(booking_date) = '$date'");
    $check_fixed = $conn->query("SELECT * FROM fixed_bookings WHERE lab='$lab' AND block='$block' AND day='$day'");
    
    $has_conflict = false;
    
    // Check fixed bookings for overlap
    if ($check_fixed->num_rows > 0) {
        while ($fixed_booking = $check_fixed->fetch_assoc()) {
            if (times_overlap($start_time, $end_time, $fixed_booking['start_time'], $fixed_booking['end_time'])) {
                $has_conflict = true;
                break;
            }
        }
    }
    
    // Check user/admin bookings for overlap
    if (!$has_conflict && $check_booked->num_rows > 0) {
        while ($booking = $check_booked->fetch_assoc()) {
            if (times_overlap($start_time, $end_time, $booking['start_time'], $booking['end_time'])) {
                $has_conflict = true;
                break;
            }
        }
    }

    if (!$has_conflict && $check_booked_labs->num_rows > 0) {
        while ($booked_lab = $check_booked_labs->fetch_assoc()) {
            if (times_overlap($start_time, $end_time, $booked_lab['start_time'], $booked_lab['end_time'])) {
                $has_conflict = true;
                break;
            }
        }
    }
    
    if ($has_conflict) {
        echo "<script>alert('Sorry, this slot conflicts with an existing booking. Please try another.'); window.history.back();</script>";
        exit;
    }

    $booking_datetime = $date . ' ' . $start_time . ':00';
    
    $stmt = $conn->prepare("INSERT INTO bookings (lab, day, start_time, end_time, block, username, booking_date, reason, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'booked')");
    $stmt->bind_param("sssssssss", $lab, $day, $start_time, $end_time, $block, $username, $booking_datetime, $reason, $phone);

    if ($stmt->execute()) {
        // HOD Notification Logic
        $hod_email = '';
        if (!empty($department)) {
            $hod_res = $conn->query("SELECT hod_email FROM hods WHERE department='$department'");
            if ($hod_res->num_rows > 0) {
                $hod_email = $hod_res->fetch_assoc()['hod_email'];
            }
        }

        if (!empty($hod_email)) {
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'ddhruva2005@gmail.com'; // Replace with your SMTP username
                $mail->Password = 'bqtw lmly cwvz ojgv'; // Replace with your SMTP password
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('ddhruva2005@gmail.com', 'Lab Booking System');
                $mail->addAddress($hod_email);
                $mail->isHTML(true);
                $mail->Subject = 'New Lab Booking Notification';
                $mail->Body = "<h3>New Lab Booking Notification</h3><p><strong>User:</strong> $username</p><p><strong>Phone:</strong> $phone</p><p><strong>Lab:</strong> $lab (Block $block)</p><p><strong>Date:</strong> " . date('d M Y', strtotime($date)) . " ($day)</p><p><strong>Time:</strong> $time</p><p><strong>Reason:</strong> $reason</p>";

                $mail->send();
                echo "<script>alert('Booking confirmed for $lab. The HOD has been notified.'); window.location='$back_link';</script>";
            } catch (Exception $e) {
                echo "<script>alert('Booking saved, but could not send email to HOD. Error: {$mail->ErrorInfo}'); window.location='$back_link';</script>";
            }
        } else {
            echo "<script>alert('Booking confirmed for $lab. (No HOD email on record for your department)'); window.location='$back_link';</script>";
        }
    } else {
        echo "<script>alert('Error: Booking could not be saved.'); window.location='$back_link';</script>";
    }
    $stmt->close();
    exit;
}

// Handle search request
$block = $_POST['block'];
$type = $_POST['type'];
$date = $_POST['date'];
$day = date('l', strtotime($date));
$capacity = $_POST['capacity']; // Get the capacity value

// Handle the time selection
if (isset($_POST['time']) && $_POST['time'] === 'custom') {
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $time = "$start_time-$end_time";
} else {
    list($start_time, $end_time) = explode('-', $_POST['time']);
    $time = $_POST['time'];
}

// Labs query with proper capacity filter
$labs_sql = "SELECT lab, capacity FROM labs WHERE block=? AND type=?";
$params = [$block, $type];
$types = "ss";

if (!empty($capacity)) {
    $labs_sql .= " AND capacity = ?"; // Changed from >= to = for exact match
    $params[] = $capacity;
    $types .= "i";
}

$stmt = $conn->prepare($labs_sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$labs_result = $stmt->get_result();

$all_labs = [];
while ($row = $labs_result->fetch_assoc()) {
    $all_labs[] = $row; // Store both lab name and capacity
}
$stmt->close();

$available_labs = [];
$booked_labs_info = [];

foreach ($all_labs as $lab_data) {
    $lab_name = $lab_data['lab'];
    $is_booked = false;

    // Check for conflicts in fixed bookings (Day-based)
    $fixed_q = $conn->query("SELECT * FROM fixed_bookings WHERE lab='$lab_name' AND block='$block' AND day='$day'");
    if ($fixed_q->num_rows > 0) {
        while ($fixed_booking = $fixed_q->fetch_assoc()) {
            if (times_overlap($start_time, $end_time, $fixed_booking['start_time'], $fixed_booking['end_time'])) {
                $is_booked = true;
                $booked_labs_info[] = [
                    'lab' => $lab_name, 
                    'username' => 'Fixed Timetable', 
                    'reason' => 'Class as per timetable',
                    'course' => $fixed_booking['course'] ?? 'N/A',
                    'capacity' => $fixed_booking['capacity'] ?? 'N/A'
                ];
                break;
            }
        }
    }

    if (!$is_booked) {
        $booked_q = $conn->query("SELECT b.*, COALESCE(u.phone, 'N/A') as phone FROM bookings b LEFT JOIN users u ON b.username = u.username WHERE b.lab='$lab_name' AND b.block='$block' AND DATE(b.booking_date) = '$date' AND b.deleted=0");
        if ($booked_q->num_rows > 0) {
            while ($booking_details = $booked_q->fetch_assoc()) {
                if (times_overlap($start_time, $end_time, $booking_details['start_time'], $booking_details['end_time'])) {
                    $is_booked = true;
                    $booked_labs_info[] = $booking_details;
                }
            }
        }
    }

    if (!$is_booked) {
        $booked_labs_q = $conn->query("SELECT * FROM booked_labs WHERE lab='$lab_name' AND block='$block' AND DATE(booking_date) = '$date'");
        if ($booked_labs_q->num_rows > 0) {
            while ($booked_lab_details = $booked_labs_q->fetch_assoc()) {
                if (times_overlap($start_time, $end_time, $booked_lab_details['start_time'], $booked_lab_details['end_time'])) {
                    $is_booked = true;
                    $booked_labs_info[] = $booked_lab_details;
                }
            }
        }
    }

    if (!$is_booked) {
        $available_labs[] = $lab_data; // Add the whole lab data array (name and capacity)
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .header {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
        }

        .header h1 i {
            color: var(--accent-primary);
        }

        .search-summary {
            color: var(--text-secondary);
            font-size: 1.1rem;
            margin-bottom: 1rem;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--bg-tertiary);
            color: var(--accent-primary);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
        }

        .back-link:hover {
            background: var(--accent-primary);
            color: white;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .results-section {
            margin-bottom: 3rem;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title.available i {
            color: var(--accent-success);
        }

        .section-title.unavailable i {
            color: var(--accent-danger);
        }

        .labs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 1.5rem;
        }

        .lab-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .lab-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .lab-card.available {
            border-left: 4px solid var(--accent-success);
        }

        .lab-card.unavailable {
            border-left: 4px solid var(--accent-danger);
        }

        .lab-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .lab-name {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .lab-name i {
            color: var(--accent-primary);
        }

        .lab-capacity {
            background: var(--bg-tertiary);
            color: var(--accent-primary);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .lab-info {
            margin-bottom: 1.5rem;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 0.75rem;
            color: var(--text-secondary);
        }

        .info-item i {
            color: var(--accent-primary);
            width: 1.2rem;
        }

        .booking-form {
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .reason-input {
            flex: 1;
            min-width: 250px;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
        }

        .reason-input:focus {
            outline: none;
            border-color: var(--accent-success);
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
        }

        .reason-input::placeholder {
            color: var(--text-muted);
        }

        .book-btn {
            background: linear-gradient(135deg, var(--accent-success), #059669);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .book-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .booked-info {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1rem;
        }

        .booked-by {
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .booked-reason {
            color: var(--text-secondary);
            font-style: italic;
        }

        .no-results {
            text-align: center;
            padding: 4rem 2rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            color: var(--text-muted);
        }

        .no-results i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .no-results h3 {
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .expired-notice {
            background: rgba(245, 158, 11, 0.1);
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 2rem;
            color: var(--accent-warning);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }

            .header h1 {
                font-size: 1.5rem;
            }

            .labs-grid {
                grid-template-columns: 1fr;
            }

            .lab-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }

            .booking-form {
                flex-direction: column;
                align-items: stretch;
            }

            .reason-input {
                min-width: auto;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                <i class="fas fa-search"></i>
                Search Results
            </h1>
            <div class="search-summary">
                Showing results for <strong><?php echo ucfirst($type); ?>s</strong> in <strong>Block <?php echo $block; ?></strong>
                on <strong><?php echo date('d M Y (l)', strtotime($date)); ?></strong>
                at <strong><?php echo $time; ?></strong>
                <?php if (!empty($capacity)): ?>
                    with capacity of <strong><?php echo $capacity; ?> people</strong>
                <?php endif; ?>
            </div>
            <a href="<?php echo $back_link; ?>" class="back-link">
                <i class="fas fa-arrow-left"></i>
                Back to Search
            </a>
        </div>

        <?php if (is_slot_expired($date, $end_time)): ?>
            <div class="expired-notice">
                <i class="fas fa-exclamation-triangle"></i>
                <span>This time slot has already passed. Bookings are not available for expired time slots.</span>
            </div>
        <?php endif; ?>

        <!-- Available Rooms -->
        <div class="results-section">
            <h2 class="section-title available">
                <i class="fas fa-check-circle"></i>
                Available Rooms (<?php echo count($available_labs); ?>)
            </h2>

            <?php if (count($available_labs) > 0 && !is_slot_expired($date, $end_time)): ?>
                <div class="labs-grid">
                    <?php foreach ($available_labs as $lab): ?>
                        <div class="lab-card available">
                            <div class="lab-header">
                                <div class="lab-name">
                                    <i class="fas fa-flask"></i>
                                    <?php echo htmlspecialchars($lab['lab']); ?>
                                </div>
                                <div class="lab-capacity">
                                    <i class="fas fa-users"></i>
                                    <?php echo $lab['capacity']; ?> people
                                </div>
                            </div>

                            <div class="lab-info">
                                <div class="info-item">
                                    <i class="fas fa-building"></i>
                                    <span>Block <?php echo htmlspecialchars($block); ?></span>
                                </div>
                                <div class="info-item">
                                    <i class="fas fa-tag"></i>
                                    <span><?php echo ucfirst($type); ?></span>
                                </div>
                                <div class="info-item">
                                    <i class="fas fa-calendar"></i>
                                    <span><?php echo date('l, M d, Y', strtotime($date)); ?></span>
                                </div>
                                <div class="info-item">
                                    <i class="fas fa-clock"></i>
                                    <span><?php echo $time; ?></span>
                                </div>
                            </div>

                            <form method="POST" class="booking-form">
                                <input type="hidden" name="block" value="<?php echo htmlspecialchars($block); ?>">
                                <input type="hidden" name="type" value="<?php echo htmlspecialchars($type); ?>">
                                <input type="hidden" name="lab" value="<?php echo htmlspecialchars($lab['lab']); ?>">
                                <input type="hidden" name="date" value="<?php echo htmlspecialchars($date); ?>">
                                <input type="hidden" name="time" value="<?php echo htmlspecialchars($time); ?>">
                                <input type="hidden" name="book_now" value="1">
                                <?php if (isset($_POST['origin'])): ?>
                                    <input type="hidden" name="origin" value="<?php echo htmlspecialchars($_POST['origin']); ?>">
                                <?php endif; ?>

                                <input type="text" name="reason" placeholder="Booking reason (required)" required class="reason-input">
                                <button type="submit" class="book-btn">
                                    <i class="fas fa-calendar-plus"></i>
                                    Book Now
                                </button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="no-results">
                    <i class="fas fa-calendar-times"></i>
                    <h3>No Available Rooms</h3>
                    <p>
                        <?php if (is_slot_expired($date, $end_time)): ?>
                            This time slot has already passed.
                        <?php else: ?>
                            No rooms are available for the selected criteria. Try different time slots or dates.
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Booked/Unavailable Rooms -->
        <div class="results-section">
            <h2 class="section-title unavailable">
                <i class="fas fa-times-circle"></i>
                Booked / Unavailable Rooms (<?php echo count($booked_labs_info); ?>)
            </h2>

            <?php if (count($booked_labs_info) > 0): ?>
                <div class="labs-grid">
                    <?php foreach ($booked_labs_info as $booking): ?>
                        <div class="lab-card unavailable">
                            <div class="lab-header">
                                <div class="lab-name">
                                    <i class="fas fa-flask"></i>
                                    <?php echo htmlspecialchars($booking['lab']); ?>
                                </div>
                            </div>

                            <div class="booked-info">
                                <div class="booked-by">
                                    <i class="fas fa-user"></i>
                                    Booked by: <?php echo htmlspecialchars($booking['username']); ?>
                                </div>
                                <div class="booked-reason">
                                    <i class="fas fa-comment"></i>
                                    Reason: <?php echo htmlspecialchars($booking['reason']); ?>
                                </div>
                                <?php if ($booking['username'] === 'Fixed Timetable'): ?>
                                    <div class="booked-reason">
                                        <i class="fas fa-book"></i>
                                        Course: <?php echo htmlspecialchars($booking['course']); ?>
                                    </div>
                                    <div class="booked-reason">
                                        <i class="fas fa-users"></i>
                                        Capacity: <?php echo htmlspecialchars($booking['capacity']); ?> people
                                    </div>
                                <?php endif; ?>
                                <?php if (isset($booking['phone']) && $booking['phone'] && $booking['phone'] !== 'N/A'): ?>
                                    <div class="booked-reason">
                                        <i class="fas fa-phone"></i>
                                        Contact: <?php echo htmlspecialchars($booking['phone']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="no-results">
                    <i class="fas fa-smile"></i>
                    <h3>No Conflicts Found</h3>
                    <p>No rooms are currently booked that conflict with this time slot.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>
