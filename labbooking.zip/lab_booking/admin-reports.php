<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Authentication Check
function isAdmin() {
    return isset($_SESSION['username']) && $_SESSION['username'] === 'admin_user';
}

if (!isAdmin()) {
    header("Location: login.php");
    exit();
}

// Database Connection
$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    error_log("DB Connection Error: " . $conn->connect_error);
    die("Database connection failed.");
}

// Handle AJAX request for username suggestions
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_users') {
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $booking_type = isset($_GET['booking_type']) ? $_GET['booking_type'] : 'live';
    
    $query = "";
    if ($booking_type == 'live') {
        $query = "SELECT DISTINCT username FROM bookings WHERE deleted = 0 AND username LIKE ? ORDER BY username LIMIT 10";
    } elseif ($booking_type == 'deleted') {
        $query = "SELECT DISTINCT username FROM deleted_bookings WHERE username LIKE ? ORDER BY username LIMIT 10";
    } else {
        $query = "SELECT DISTINCT username FROM booked_labs WHERE username LIKE ? ORDER BY username LIMIT 10";
    }
    
    $stmt = $conn->prepare($query);
    $search_param = "%$search%";
    $stmt->bind_param("s", $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row['username'];
    }
    
    header('Content-Type: application/json');
    echo json_encode($users);
    exit();
}

// Initialize filter variables
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';
$user_filter = isset($_GET['user_filter']) ? $_GET['user_filter'] : '';
$block_filter = isset($_GET['block_filter']) ? $_GET['block_filter'] : '';
$booking_type = isset($_GET['booking_type']) ? $_GET['booking_type'] : 'live';

// Handle CSV download
if (isset($_GET['download_csv']) && $_GET['download_csv'] == '1') {
    $query = "";
    $params = [];
    $types = "";
    
    // Build query based on booking type
    if ($booking_type == 'live') {
        $query = "SELECT id, lab, block, day, start_time, end_time, username, reason, phone, booking_date 
                  FROM bookings WHERE deleted = 0";
    } elseif ($booking_type == 'deleted') {
        $query = "SELECT id, lab, block, day, start_time, end_time, username, reason, delete_reason, deleted_at 
                  FROM deleted_bookings WHERE 1=1";
    } elseif ($booking_type == 'booked') {
        $query = "SELECT id, lab, block, day, start_time, end_time, username, reason, phone, booking_date 
                  FROM booked_labs WHERE 1=1";
    }
    
    // Add filters
    if (!empty($date_from)) {
        if ($booking_type == 'deleted') {
            $query .= " AND DATE(deleted_at) >= ?";
        } else {
            $query .= " AND DATE(booking_date) >= ?";
        }
        $params[] = $date_from;
        $types .= "s";
    }
    
    if (!empty($date_to)) {
        if ($booking_type == 'deleted') {
            $query .= " AND DATE(deleted_at) <= ?";
        } else {
            $query .= " AND DATE(booking_date) <= ?";
        }
        $params[] = $date_to;
        $types .= "s";
    }
    
    if (!empty($user_filter)) {
        $query .= " AND username LIKE ?";
        $params[] = "%$user_filter%";
        $types .= "s";
    }
    
    if (!empty($block_filter)) {
        $query .= " AND block = ?";
        $params[] = $block_filter;
        $types .= "s";
    }
    
    $query .= " ORDER BY " . ($booking_type == 'deleted' ? 'deleted_at' : 'booking_date') . " DESC";
    
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Set headers for CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $booking_type . '_bookings_' . date('Y-m-d_H-i-s') . '.csv"');
    
    // Create file pointer
    $output = fopen('php://output', 'w');
    
    // Add CSV headers based on booking type
    if ($booking_type == 'deleted') {
        fputcsv($output, ['ID', 'Lab', 'Block', 'Day', 'Start Time', 'End Time', 'Username', 'Reason', 'Delete Reason', 'Deleted At']);
    } else {
        fputcsv($output, ['ID', 'Lab', 'Block', 'Day', 'Start Time', 'End Time', 'Username', 'Reason', 'Phone', 'Booking Date']);
    }
    
    // Add data rows
    while ($row = $result->fetch_assoc()) {
        if ($booking_type == 'deleted') {
            fputcsv($output, [
                $row['id'], $row['lab'], $row['block'], $row['day'], 
                $row['start_time'], $row['end_time'], $row['username'], 
                $row['reason'], $row['delete_reason'], $row['deleted_at']
            ]);
        } else {
            fputcsv($output, [
                $row['id'], $row['lab'], $row['block'], $row['day'], 
                $row['start_time'], $row['end_time'], $row['username'], 
                $row['reason'], $row['phone'], $row['booking_date']
            ]);
        }
    }
    
    fclose($output);
    exit();
}

// Get all blocks for dropdown based on booking type
if ($booking_type == 'live') {
    $blocks_query = "SELECT DISTINCT block FROM bookings WHERE deleted = 0 ORDER BY block";
} elseif ($booking_type == 'deleted') {
    $blocks_query = "SELECT DISTINCT block FROM deleted_bookings ORDER BY block";
} else {
    $blocks_query = "SELECT DISTINCT block FROM booked_labs ORDER BY block";
}
$blocks_result = $conn->query($blocks_query);

// Build query for display with filters
$display_query = "";
$display_params = [];
$display_types = "";

if ($booking_type == 'live') {
    $display_query = "SELECT id, lab, block, day, start_time, end_time, username, reason, phone, booking_date 
                      FROM bookings WHERE deleted = 0";
} elseif ($booking_type == 'deleted') {
    $display_query = "SELECT id, lab, block, day, start_time, end_time, username, reason, delete_reason, deleted_at 
                      FROM deleted_bookings WHERE 1=1";
} elseif ($booking_type == 'booked') {
    $display_query = "SELECT id, lab, block, day, start_time, end_time, username, reason, phone, booking_date 
                      FROM booked_labs WHERE 1=1";
}

// Add filters
if (!empty($date_from)) {
    if ($booking_type == 'deleted') {
        $display_query .= " AND DATE(deleted_at) >= ?";
    } else {
        $display_query .= " AND DATE(booking_date) >= ?";
    }
    $display_params[] = $date_from;
    $display_types .= "s";
}

if (!empty($date_to)) {
    if ($booking_type == 'deleted') {
        $display_query .= " AND DATE(deleted_at) <= ?";
    } else {
        $display_query .= " AND DATE(booking_date) <= ?";
    }
    $display_params[] = $date_to;
    $display_types .= "s";
}

if (!empty($user_filter)) {
    $display_query .= " AND username LIKE ?";
    $display_params[] = "%$user_filter%";
    $display_types .= "s";
}

if (!empty($block_filter)) {
    $display_query .= " AND block = ?";
    $display_params[] = $block_filter;
    $display_types .= "s";
}

$display_query .= " ORDER BY " . ($booking_type == 'deleted' ? 'deleted_at' : 'booking_date') . " DESC LIMIT 100";

$display_stmt = $conn->prepare($display_query);
if (!empty($display_params)) {
    $display_stmt->bind_param($display_types, ...$display_params);
}
$display_stmt->execute();
$display_result = $display_stmt->get_result();

// Get total count for the current filters
$count_query = str_replace("SELECT id, lab, block, day, start_time, end_time, username, reason, phone, booking_date", "SELECT COUNT(*)", $display_query);
$count_query = str_replace("SELECT id, lab, block, day, start_time, end_time, username, reason, delete_reason, deleted_at", "SELECT COUNT(*)", $count_query);
$count_query = str_replace("ORDER BY booking_date DESC LIMIT 100", "", $count_query);
$count_query = str_replace("ORDER BY deleted_at DESC LIMIT 100", "", $count_query);

$count_stmt = $conn->prepare($count_query);
if (!empty($display_params)) {
    $count_stmt->bind_param($display_types, ...$display_params);
}
$count_stmt->execute();
$total_records = $count_stmt->get_result()->fetch_row()[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Reports - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .admin-badge {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Filters Section */
        .filters-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title i {
            color: var(--accent-primary);
        }

        .filters-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            align-items: end;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            position: relative;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .form-select,
        .form-input {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-select:focus,
        .form-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-select option {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        /* Username Search with Suggestions */
        .username-search {
            position: relative;
        }

        .username-input {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
            width: 100%;
        }

        .username-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .suggestions-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            max-height: 200px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
            margin-top: 4px;
        }

        .suggestion-item {
            padding: 0.75rem 1rem;
            cursor: pointer;
            color: var(--text-secondary);
            transition: all 0.3s ease;
            border-bottom: 1px solid var(--border-color);
        }

        .suggestion-item:last-child {
            border-bottom: none;
        }

        .suggestion-item:hover,
        .suggestion-item.active {
            background: var(--bg-card);
            color: var(--text-primary);
        }

        .filter-btn {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            height: fit-content;
        }

        .filter-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .clear-btn {
            background: var(--bg-tertiary);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            height: fit-content;
        }

        .clear-btn:hover {
            background: var(--bg-primary);
            transform: translateY(-1px);
        }

        /* Results Section */
        .results-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
        }

        .results-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .results-info {
            color: var(--text-secondary);
            font-weight: 500;
        }

        .download-btn {
            background: linear-gradient(135deg, var(--accent-success), #059669);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .download-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .results-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--bg-tertiary);
            border-radius: 16px;
            overflow: hidden;
            border: 1px solid var(--border-color);
        }

        .results-table th,
        .results-table td {
            padding: 1rem 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .results-table th {
            background: var(--bg-primary);
            font-weight: 600;
            color: var(--text-primary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .results-table td {
            color: var(--text-secondary);
        }

        .results-table tr:hover {
            background: var(--bg-card);
        }

        .results-table tr:last-child td {
            border-bottom: none;
        }

        .no-results {
            text-align: center;
            color: var(--text-muted);
            padding: 3rem;
            background: var(--bg-tertiary);
            border-radius: 16px;
            border: 1px dashed var(--border-color);
        }

        .no-results i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--text-muted);
            opacity: 0.5;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-left: 0;
            }

            .top-header {
                padding: 1rem;
            }

            .header-title {
                font-size: 1.5rem;
            }

            .content {
                padding: 1rem;
            }

            .filters-form {
                grid-template-columns: 1fr;
            }

            .results-header {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                    <span class="admin-badge">ADMIN</span>
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="admin.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        All Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-reports.php" class="nav-link active">
                        <i class="fas fa-file-download"></i>
                        Download Reports
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        System Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-manage-users.php" class="nav-link">
                        <i class="fas fa-users-cog"></i>
                        Manage Users
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">Booking Reports</h1>
                <div class="header-actions">
                    <a href="?logout=true" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                <!-- Filters Section -->
                <div class="filters-section">
                    <h2 class="section-title">
                        <i class="fas fa-filter"></i>
                        Filter Reports
                    </h2>
                    <form method="GET" action="" class="filters-form">
                        <div class="form-group">
                            <label class="form-label">Booking Type</label>
                            <select name="booking_type" class="form-select" id="booking-type-select">
                                <option value="live" <?php echo ($booking_type == 'live') ? 'selected' : ''; ?>>Live Bookings</option>
                                <option value="booked" <?php echo ($booking_type == 'booked') ? 'selected' : ''; ?>>Completed Bookings</option>
                                <option value="deleted" <?php echo ($booking_type == 'deleted') ? 'selected' : ''; ?>>Cancelled Bookings</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">From Date</label>
                            <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" class="form-input">
                        </div>

                        <div class="form-group">
                            <label class="form-label">To Date</label>
                            <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" class="form-input">
                        </div>

                        <div class="form-group username-search">
                            <label class="form-label">Username</label>
                            <input type="text" name="user_filter" value="<?php echo htmlspecialchars($user_filter); ?>" 
                                   class="username-input" id="username-input" placeholder="Search username..." autocomplete="off">
                            <div class="suggestions-dropdown" id="suggestions-dropdown"></div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Block</label>
                            <select name="block_filter" class="form-select">
                                <option value="">All Blocks</option>
                                <?php while ($block = $blocks_result->fetch_assoc()): ?>
                                    <option value="<?php echo htmlspecialchars($block['block']); ?>" 
                                            <?php echo ($block_filter == $block['block']) ? 'selected' : ''; ?>>
                                        Block <?php echo htmlspecialchars($block['block']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <button type="submit" class="filter-btn">
                            <i class="fas fa-filter"></i>
                            Apply Filters
                        </button>

                        <a href="admin-reports.php" class="clear-btn">
                            <i class="fas fa-times"></i>
                            Clear
                        </a>
                    </form>
                </div>

                <!-- Results Section -->
                <div class="results-section">
                    <div class="results-header">
                        <div class="results-info">
                            <i class="fas fa-info-circle"></i>
                            <strong>Total Records: <?php echo $total_records; ?></strong>
                            <?php if ($total_records > 100): ?>
                                (Showing first 100 records. Download CSV for all records.)
                            <?php endif; ?>
                        </div>
                        <?php if ($total_records > 0): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['download_csv' => '1'])); ?>" class="download-btn">
                                <i class="fas fa-download"></i>
                                Download CSV (<?php echo $total_records; ?> records)
                            </a>
                        <?php endif; ?>
                    </div>

                    <?php if ($display_result->num_rows > 0): ?>
                        <table class="results-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Lab</th>
                                    <th>Block</th>
                                    <th>Day</th>
                                    <th>Time</th>
                                    <th>Username</th>
                                    <th>Reason</th>
                                    <?php if ($booking_type == 'deleted'): ?>
                                        <th>Delete Reason</th>
                                        <th>Deleted At</th>
                                    <?php else: ?>
                                        <th>Phone</th>
                                        <th>Booking Date</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $display_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['lab']); ?></td>
                                        <td>Block <?php echo htmlspecialchars($row['block']); ?></td>
                                        <td><?php echo htmlspecialchars($row['day']); ?></td>
                                        <td><?php echo htmlspecialchars($row['start_time']) . ' - ' . htmlspecialchars($row['end_time']); ?></td>
                                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                                        <td><?php echo htmlspecialchars($row['reason']); ?></td>
                                        <?php if ($booking_type == 'deleted'): ?>
                                            <td><?php echo htmlspecialchars($row['delete_reason']); ?></td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($row['deleted_at'])); ?></td>
                                        <?php else: ?>
                                            <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($row['booking_date'])); ?></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-results">
                            <i class="fas fa-search"></i>
                            <h3>No Records Found</h3>
                            <p>No <?php echo $booking_type; ?> bookings match your current filter criteria.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const usernameInput = document.getElementById('username-input');
            const suggestionsDropdown = document.getElementById('suggestions-dropdown');
            const bookingTypeSelect = document.getElementById('booking-type-select');
            let currentSuggestions = [];
            let selectedIndex = -1;

            function fetchSuggestions(query, bookingType) {
                if (query.length < 1) {
                    suggestionsDropdown.style.display = 'none';
                    return;
                }

                fetch(`?ajax=get_users&search=${encodeURIComponent(query)}&booking_type=${bookingType}`)
                    .then(response => response.json())
                    .then(users => {
                        currentSuggestions = users;
                        displaySuggestions(users);
                    })
                    .catch(error => {
                        console.error('Error fetching suggestions:', error);
                        suggestionsDropdown.style.display = 'none';
                    });
            }

            function displaySuggestions(users) {
                if (users.length === 0) {
                    suggestionsDropdown.style.display = 'none';
                    return;
                }

                suggestionsDropdown.innerHTML = '';
                users.forEach((user, index) => {
                    const item = document.createElement('div');
                    item.className = 'suggestion-item';
                    item.textContent = user;
                    item.addEventListener('click', () => {
                        usernameInput.value = user;
                        suggestionsDropdown.style.display = 'none';
                        selectedIndex = -1;
                    });
                    suggestionsDropdown.appendChild(item);
                });

                suggestionsDropdown.style.display = 'block';
                selectedIndex = -1;
            }

            usernameInput.addEventListener('input', function() {
                const query = this.value.trim();
                const bookingType = bookingTypeSelect.value;
                fetchSuggestions(query, bookingType);
            });

            usernameInput.addEventListener('keydown', function(e) {
                const items = suggestionsDropdown.querySelectorAll('.suggestion-item');
                
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
                    updateSelection(items);
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    selectedIndex = Math.max(selectedIndex - 1, -1);
                    updateSelection(items);
                } else if (e.key === 'Enter' && selectedIndex >= 0) {
                    e.preventDefault();
                    usernameInput.value = currentSuggestions[selectedIndex];
                    suggestionsDropdown.style.display = 'none';
                    selectedIndex = -1;
                } else if (e.key === 'Escape') {
                    suggestionsDropdown.style.display = 'none';
                    selectedIndex = -1;
                }
            });

            function updateSelection(items) {
                items.forEach((item, index) => {
                    item.classList.toggle('active', index === selectedIndex);
                });
            }

            // Hide suggestions when clicking outside
            document.addEventListener('click', function(e) {
                if (!usernameInput.contains(e.target) && !suggestionsDropdown.contains(e.target)) {
                    suggestionsDropdown.style.display = 'none';
                    selectedIndex = -1;
                }
            });

            // Update suggestions when booking type changes
            bookingTypeSelect.addEventListener('change', function() {
                const query = usernameInput.value.trim();
                if (query.length >= 1) {
                    fetchSuggestions(query, this.value);
                }
            });
        });
    </script>
</body>
</html>
