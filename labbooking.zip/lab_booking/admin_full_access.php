<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Authentication Check
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin_user') {
    header("Location: login.php");
    exit;
}

// Database Connection
$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ================================================================
// == FIXED: Handle booking cancellation using Hard Delete       ==
// ================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // Sanitize all incoming POST data
    $lab = $conn->real_escape_string($_POST['lab']);
    $block = $conn->real_escape_string($_POST['block']);
    $type = $conn->real_escape_string($_POST['type']);
    $date = $conn->real_escape_string($_POST['date']);
    $day = date('l', strtotime($date));
    $time = $conn->real_escape_string($_POST['time']);
    list($start_time, $end_time) = explode('-', $time);

    if ($action === 'book') {
        $reason = $conn->real_escape_string($_POST['reason']);
        $username = 'admin_user';
        $phone = 'N/A';
        
        $stmt = $conn->prepare("INSERT INTO bookings (lab, day, start_time, end_time, block, username, booking_date, reason, phone, status) VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, ?, 'booked')");
        $stmt->bind_param("ssssssss", $lab, $day, $start_time, $end_time, $block, $username, $reason, $phone);
        $stmt->execute();
        $stmt->close();

    } elseif ($action === 'delete') {
        $booking_id = (int)$_POST['booking_id'];
        $delete_reason = $conn->real_escape_string($_POST['delete_reason']);
        
        $res = $conn->query("SELECT * FROM bookings WHERE id=$booking_id AND deleted=0");
        if ($res->num_rows > 0) {
            $booking = $res->fetch_assoc();
            
            $conn->query("INSERT INTO deleted_bookings (lab, day, start_time, end_time, block, username, booking_date, reason, delete_reason)
                          VALUES ('{$booking['lab']}', '{$booking['day']}', '{$booking['start_time']}', '{$booking['end_time']}', '{$booking['block']}', '{$booking['username']}', '{$booking['booking_date']}', '{$booking['reason']}', 'Admin Grid: $delete_reason')");
            
            $conn->query("DELETE FROM bookings WHERE id=$booking_id");
        }
    }

    header("Location: admin_full_access.php?block=$block&type=$type");
    exit;
}

// Static Data for Forms & Grid
$blocks = ['A','B','C','D','E','F','M'];
$types = ['lab', 'classroom', 'interactive'];
$time_slots = ['08:00-10:00', '09:00-11:00', '10:30-12:30', '11:30-13:30', '13:30-15:30', '14:30-16:30'];
$days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
$days = [];
for ($i = 0; $i < 7; $i++) {
    $timestamp = strtotime("+$i days");
    $days[] = ['label' => date('l', $timestamp), 'date' => date('Y-m-d', $timestamp)];
}

function timeToMinutes($time) {
    list($hours, $minutes) = explode(':', $time);
    return (int)$hours * 60 + (int)$minutes;
}

function getBookingStyle($start_time, $end_time) {
    $start_min = timeToMinutes($start_time);
    $end_min = timeToMinutes($end_time);
    $day_start = timeToMinutes('08:00');
    $day_end = timeToMinutes('18:00');
    
    $left = (($start_min - $day_start) / ($day_end - $day_start)) * 100;
    $width = (($end_min - $start_min) / ($day_end - $day_start)) * 100;
    
    return "left: {$left}%; width: {$width}%;";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Full Access Grid - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .back-btn {
            background: var(--bg-tertiary);
            color: var(--accent-primary);
            padding: 0.75rem 1.5rem;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .back-btn:hover {
            background: var(--accent-primary);
            color: white;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Filter Section */
        .filter-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-md);
        }

        .filter-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .filter-title i {
            color: var(--accent-primary);
        }

        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1.5rem;
            align-items: end;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .form-select {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .form-select:hover {
            border-color: var(--accent-primary);
        }

        .form-select:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-select option {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .load-btn {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            height: 44px;
        }

        .load-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .load-btn:active {
            transform: translateY(0);
        }

        /* Grid Section */
        .grid-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: var(--shadow-md);
        }

        .grid-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 2rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
        }

        .grid-title i {
            color: var(--accent-primary);
        }

        .lab-section {
            margin-bottom: 3rem;
        }

        .lab-section:last-child {
            margin-bottom: 0;
        }

        .lab-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            padding: 1rem 1.5rem;
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(124, 58, 237, 0.1));
            border-radius: 12px;
            border-left: 4px solid var(--accent-primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .lab-title i {
            color: var(--accent-primary);
            font-size: 1.2rem;
        }

        /* Timeline view styles for handling overlapping bookings */
        .timeline-container {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            overflow-x: auto;
            margin-bottom: 2rem;
        }

        .timeline-wrapper {
            min-width: 100%;
            display: flex;
            flex-direction: column;
        }

        .timeline-header {
            display: flex;
            border-bottom: 2px solid var(--border-color);
            background: var(--bg-secondary);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .timeline-day-label {
            min-width: 140px;
            padding: 1rem;
            font-weight: 600;
            color: var(--text-primary);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .timeline-day-name {
            font-size: 0.95rem;
        }

        .timeline-day-date {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-top: 0.25rem;
        }

        .timeline-hours {
            flex: 1;
            display: flex;
            border-left: 1px solid var(--border-color);
        }

        .timeline-hour {
            flex: 1;
            min-width: 80px;
            padding: 0.75rem;
            text-align: center;
            font-size: 0.8rem;
            color: var(--text-muted);
            border-right: 1px solid var(--border-color);
            font-weight: 500;
        }

        .timeline-hour:last-child {
            border-right: none;
        }

        .timeline-row {
            display: flex;
            border-bottom: 1px solid var(--border-color);
            min-height: 100px;
            position: relative;
        }

        .timeline-row:last-child {
            border-bottom: none;
        }

        .timeline-row-label {
            min-width: 140px;
            padding: 1rem;
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: var(--bg-secondary);
            font-weight: 500;
            color: var(--text-primary);
            font-size: 0.9rem;
        }

        .timeline-row-content {
            flex: 1;
            position: relative;
            display: flex;
            align-items: stretch;
        }

        .timeline-grid-line {
            position: absolute;
            top: 0;
            bottom: 0;
            width: 1px;
            background: var(--border-color);
            opacity: 0.3;
        }

        /* Booking block styles for timeline view */
        .booking-block {
            position: absolute;
            top: 8px;
            bottom: 8px;
            border-radius: 8px;
            padding: 0.75rem;
            font-size: 0.8rem;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: var(--shadow-md);
        }

        .booking-block:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
            z-index: 20;
        }

        .booking-block.booked {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(220, 38, 38, 0.2));
            border-color: var(--accent-danger);
            color: #fca5a5;
        }

        .booking-block.fixed {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(217, 119, 6, 0.2));
            border-color: var(--accent-warning);
            color: #fcd34d;
        }

        .booking-block.available {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(5, 150, 105, 0.2));
            border-color: var(--accent-success);
            color: #86efac;
        }

        .booking-block-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .booking-block-info {
            font-size: 0.75rem;
            opacity: 0.9;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .booking-block-time {
            font-size: 0.75rem;
            opacity: 0.8;
            margin-top: 0.25rem;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2rem;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
            animation: slideUp 0.3s ease;
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .modal-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .modal-close {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .modal-close:hover {
            color: var(--text-primary);
        }

        .modal-body {
            margin-bottom: 1.5rem;
        }

        .modal-field {
            margin-bottom: 1rem;
        }

        .modal-label {
            display: block;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
        }

        .modal-value {
            color: var(--text-primary);
            font-size: 0.95rem;
        }

        .modal-input {
            width: 100%;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 0.75rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .modal-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .modal-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
        }

        .modal-btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }

        .modal-btn-cancel {
            background: var(--bg-tertiary);
            color: var(--text-secondary);
            border: 1px solid var(--border-color);
        }

        .modal-btn-cancel:hover {
            background: var(--border-color);
            color: var(--text-primary);
        }

        .modal-btn-delete {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
        }

        .modal-btn-delete:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .modal-btn-book {
            background: linear-gradient(135deg, var(--accent-success), #059669);
            color: white;
        }

        .modal-btn-book:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }

        .no-grid {
            text-align: center;
            color: var(--text-muted);
            padding: 4rem 2rem;
            background: var(--bg-tertiary);
            border-radius: 16px;
            border: 2px dashed var(--border-color);
        }

        .no-grid i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .no-grid h3 {
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
            color: var(--text-secondary);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-left: 0;
            }

            .content {
                padding: 1rem;
            }

            .filter-form {
                grid-template-columns: 1fr;
            }

            .timeline-day-label,
            .timeline-row-label {
                min-width: 100px;
                padding: 0.75rem;
                font-size: 0.8rem;
            }

            .timeline-hour {
                min-width: 60px;
                font-size: 0.7rem;
            }

            .booking-block {
                font-size: 0.7rem;
                padding: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="admin.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-reports.php" class="nav-link">
                        <i class="fas fa-file-download"></i>
                        Download Reports
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        My Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-manage-users.php" class="nav-link">
                        <i class="fas fa-users-cog"></i>
                        Manage Users
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">
                    <i class="fas fa-calendar-alt"></i>
                    Admin Full Access Grid
                </h1>
                <div class="header-actions">
                    <a href="admin.php" class="back-btn">
                        <i class="fas fa-arrow-left"></i>
                        Back
                    </a>
                </div>
            </header>

            <div class="content">
                <!-- Filter Form -->
                <div class="filter-section">
                    <h2 class="filter-title">
                        <i class="fas fa-sliders-h"></i>
                        Filter & View
                    </h2>
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label class="form-label">Block</label>
                            <select name="block" required class="form-select">
                                <option value="">Select Block</option>
                                <?php foreach ($blocks as $b): ?>
                                    <option value="<?php echo $b; ?>" <?php if (isset($_GET['block']) && $_GET['block'] === $b) echo 'selected'; ?>>
                                        Block <?php echo $b; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Type</label>
                            <select name="type" required class="form-select">
                                <option value="">Select Type</option>
                                <?php foreach ($types as $t): ?>
                                    <option value="<?php echo $t; ?>" <?php if (isset($_GET['type']) && $_GET['type'] === $t) echo 'selected'; ?>>
                                        <?php echo ucfirst($t); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Day (Optional)</label>
                            <select name="day" class="form-select">
                                <option value="">All Days</option>
                                <?php foreach ($days_of_week as $d): ?>
                                    <option value="<?php echo $d; ?>" <?php if (isset($_GET['day']) && $_GET['day'] === $d) echo 'selected'; ?>>
                                        <?php echo $d; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <button type="submit" class="load-btn">
                            <i class="fas fa-sync-alt"></i>
                            Load Timeline
                        </button>
                    </form>
                </div>

                <?php
                // Grid Generation
                if (isset($_GET['block']) && isset($_GET['type'])):
                    $selected_block = $_GET['block'];
                    $selected_type = $_GET['type'];
                    $selected_day = isset($_GET['day']) && $_GET['day'] !== '' ? $_GET['day'] : null;
                    
                    // Get all labs for the selected filter
                    $labs = [];
                    $res = $conn->query("SELECT lab FROM labs WHERE block='$selected_block' AND type='$selected_type'");
                    while ($row = $res->fetch_assoc()) $labs[] = $row['lab'];
                ?>
                    <div class="grid-section">
                        <h2 class="grid-title">
                            <i class="fas fa-chart-timeline"></i>
                            Timeline View - <?php echo ucfirst($selected_type); ?>s in Block <?php echo $selected_block; ?>
                        </h2>
                        
                        <?php foreach ($labs as $lab): ?>
                            <div class="lab-section">
                                <h3 class="lab-title">
                                    <i class="fas fa-flask-vial"></i>
                                    <?php echo htmlspecialchars($lab); ?>
                                </h3>

                                <div class="timeline-container">
                                    <div class="timeline-wrapper">
                                        <!-- Timeline Header with Hours -->
                                        <div class="timeline-header">
                                            <div class="timeline-day-label">Date</div>
                                            <div class="timeline-hours">
                                                <?php for ($h = 8; $h < 18; $h++): ?>
                                                    <div class="timeline-hour"><?php echo str_pad($h, 2, '0', STR_PAD_LEFT); ?>:00</div>
                                                <?php endfor; ?>
                                            </div>
                                        </div>

                                        <!-- Timeline Rows for Each Day -->
                                        <?php 
                                        $filtered_days = $days;
                                        if ($selected_day) {
                                            $filtered_days = array_filter($days, function($d) use ($selected_day) {
                                                return $d['label'] === $selected_day;
                                            });
                                        }
                                        foreach ($filtered_days as $d): 
                                        ?>
                                            <div class="timeline-row">
                                                <div class="timeline-row-label">
                                                    <div class="timeline-day-name"><?php echo substr($d['label'], 0, 3); ?></div>
                                                    <div class="timeline-day-date"><?php echo date('M d', strtotime($d['date'])); ?></div>
                                                </div>
                                                <div class="timeline-row-content">
                                                    <!-- Grid lines for hours -->
                                                    <?php for ($h = 8; $h < 18; $h++): ?>
                                                        <div class="timeline-grid-line" style="left: <?php echo (($h - 8) / 10) * 100; ?>%;"></div>
                                                    <?php endfor; ?>

                                                    <!-- Bookings for this day -->
                                                    <?php
                                                    $day_name = $d['label'];
                                                    
                                                    // Get all bookings and fixed bookings for this day
                                                    $bookings = [];
                                                    
                                                    // Get user bookings
                                                    $book_res = $conn->query("SELECT * FROM bookings WHERE lab='$lab' AND block='$selected_block' AND day='$day_name' ORDER BY start_time ASC");
                                                    while ($row = $book_res->fetch_assoc()) {
                                                        $row['type'] = 'booked';
                                                        $bookings[] = $row;
                                                    }
                                                    
                                                    // Get fixed bookings
                                                    $fixed_res = $conn->query("SELECT * FROM fixed_bookings WHERE lab='$lab' AND block='$selected_block' AND day='$day_name' ORDER BY start_time ASC");
                                                    while ($row = $fixed_res->fetch_assoc()) {
                                                        $row['type'] = 'fixed';
                                                        $bookings[] = $row;
                                                    }
                                                    
                                                    // Sort by start time
                                                    usort($bookings, function($a, $b) {
                                                        return strcmp($a['start_time'], $b['start_time']);
                                                    });
                                                    
                                                    // Display bookings
                                                    foreach ($bookings as $booking):
                                                        $style = getBookingStyle($booking['start_time'], $booking['end_time']);
                                                        $class = $booking['type'] === 'fixed' ? 'fixed' : 'booked';
                                                        $title = $booking['type'] === 'fixed' ? $booking['course'] : $booking['username'];
                                                        $info = $booking['type'] === 'fixed' ? 'Cap: ' . $booking['capacity'] : $booking['reason'];
                                                    ?>
                                                        <div class="booking-block <?php echo $class; ?>" style="<?php echo $style; ?>" onclick="openModal('<?php echo $booking['type']; ?>', <?php echo json_encode($booking); ?>)">
                                                            <div class="booking-block-title"><?php echo htmlspecialchars($title); ?></div>
                                                            <div class="booking-block-info"><?php echo htmlspecialchars($info); ?></div>
                                                            <div class="booking-block-time"><?php echo $booking['start_time']; ?> - <?php echo $booking['end_time']; ?></div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="no-grid">
                        <i class="fas fa-inbox"></i>
                        <h3>No Timeline Selected</h3>
                        <p>Please select a block and type from the filter above to load the timeline view.</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Modal for Booking Details -->
    <div id="bookingModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="modalTitle">Booking Details</h2>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body" id="modalBody"></div>
            <div class="modal-actions" id="modalActions"></div>
        </div>
    </div>

    <script>
        let currentBooking = null;

        function openModal(type, booking) {
            currentBooking = booking;
            const modal = document.getElementById('bookingModal');
            const modalTitle = document.getElementById('modalTitle');
            const modalBody = document.getElementById('modalBody');
            const modalActions = document.getElementById('modalActions');

            if (type === 'fixed') {
                modalTitle.textContent = 'Fixed Booking Details';
                modalBody.innerHTML = `
                    <div class="modal-field">
                        <label class="modal-label">Course</label>
                        <div class="modal-value">${booking.course}</div>
                    </div>
                    <div class="modal-field">
                        <label class="modal-label">Capacity</label>
                        <div class="modal-value">${booking.capacity}</div>
                    </div>
                    <div class="modal-field">
                        <label class="modal-label">Time</label>
                        <div class="modal-value">${booking.start_time} - ${booking.end_time}</div>
                    </div>
                    <div class="modal-field">
                        <label class="modal-label">Day</label>
                        <div class="modal-value">${booking.day}</div>
                    </div>
                `;
                modalActions.innerHTML = `<button class="modal-btn modal-btn-cancel" onclick="closeModal()">Close</button>`;
            } else {
                modalTitle.textContent = 'Booking Details';
                modalBody.innerHTML = `
                    <div class="modal-field">
                        <label class="modal-label">Username</label>
                        <div class="modal-value">${booking.username}</div>
                    </div>
                    <div class="modal-field">
                        <label class="modal-label">Reason</label>
                        <div class="modal-value">${booking.reason}</div>
                    </div>
                    <div class="modal-field">
                        <label class="modal-label">Phone</label>
                        <div class="modal-value">${booking.phone}</div>
                    </div>
                    <div class="modal-field">
                        <label class="modal-label">Time</label>
                        <div class="modal-value">${booking.start_time} - ${booking.end_time}</div>
                    </div>
                    <div class="modal-field">
                        <label class="modal-label">Delete Reason</label>
                        <input type="text" id="deleteReason" class="modal-input" placeholder="Enter reason for deletion" required>
                    </div>
                `;
                modalActions.innerHTML = `
                    <button class="modal-btn modal-btn-cancel" onclick="closeModal()">Cancel</button>
                    <button class="modal-btn modal-btn-delete" onclick="deleteBooking()">Delete Booking</button>
                `;
            }

            modal.classList.add('show');
        }

        function closeModal() {
            document.getElementById('bookingModal').classList.remove('show');
            currentBooking = null;
        }

        function deleteBooking() {
            const deleteReason = document.getElementById('deleteReason').value;
            if (!deleteReason.trim()) {
                alert('Please enter a reason for deletion');
                return;
            }

            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="booking_id" value="${currentBooking.id}">
                <input type="hidden" name="lab" value="${currentBooking.lab}">
                <input type="hidden" name="block" value="${currentBooking.block}">
                <input type="hidden" name="type" value="lab">
                <input type="hidden" name="date" value="${new Date().toISOString().split('T')[0]}">
                <input type="hidden" name="time" value="${currentBooking.start_time}-${currentBooking.end_time}">
                <input type="hidden" name="delete_reason" value="${deleteReason}">
            `;
            document.body.appendChild(form);
            form.submit();
        }

        // Close modal when clicking outside
        document.getElementById('bookingModal').addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>
