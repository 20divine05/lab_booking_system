<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Authentication check
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// Get popular labs based on booking frequency
$popular_labs = [];
$popular_sql = "SELECT lab, COUNT(*) as booking_count 
                FROM booked_labs 
                GROUP BY lab 
                ORDER BY booking_count DESC 
                LIMIT 5";
$popular_result = $conn->query($popular_sql);
if ($popular_result && $popular_result->num_rows > 0) {
    while ($row = $popular_result->fetch_assoc()) {
        $popular_labs[] = $row;
    }
}

// FIXED: Get available capacities with proper display
$capacities = [30, 45, 60]; // Fixed capacity values

// Get recent searches (you can implement this based on your needs)
$recent_searches = [
    ['block' => 'A', 'type' => 'lab', 'time' => '08:30-10:30'],
    ['block' => 'M', 'type' => 'classroom', 'time' => '11:00-13:00'],
    ['block' => 'B', 'type' => 'interactive', 'time' => '14:00-16:00']
];

// Handle search form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Forward the POST data to search_available.php
    $postData = http_build_query($_POST);
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-type: application/x-www-form-urlencoded',
            'content' => $postData
        ]
    ]);
    
    // Include the search_available.php file
    include 'search_available.php';
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Rooms - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-tertiary);
            border-radius: 12px;
            border: 1px solid var(--border-color);
        }

        .user-avatar {
            width: 2.5rem;
            height: 2.5rem;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Search Section */
        .search-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title i {
            color: var(--accent-primary);
        }

        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            align-items: end;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .form-select,
        .form-input {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-select:focus,
        .form-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-select option {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .search-btn {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            height: fit-content;
        }

        .search-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        /* Grid Layout */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .card:hover {
            box-shadow: var(--shadow-lg);
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .card-title i {
            color: var(--accent-primary);
        }

        /* Filter Tags */
        .filter-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }

        .filter-tag {
            background: var(--bg-tertiary);
            color: var(--text-secondary);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
        }

        .filter-tag:hover,
        .filter-tag.active {
            background: var(--accent-primary);
            color: white;
            border-color: var(--accent-primary);
        }

        /* Popular Labs */
        .popular-lab {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .popular-lab:last-child {
            border-bottom: none;
        }

        .lab-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .lab-icon {
            width: 2.5rem;
            height: 2.5rem;
            background: var(--accent-primary);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .lab-name {
            color: var(--text-primary);
            font-weight: 500;
        }

        .lab-count {
            background: var(--bg-tertiary);
            color: var(--accent-primary);
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        /* Recent Searches */
        .recent-search {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .recent-search:hover {
            background: var(--bg-primary);
            border-color: var(--accent-primary);
        }

        .recent-search:last-child {
            margin-bottom: 0;
        }

        .search-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }

        .search-block {
            background: var(--accent-primary);
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 8px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .search-meta {
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        /* Advanced Search Toggle */
        .advanced-toggle {
            background: none;
            border: none;
            color: var(--accent-primary);
            cursor: pointer;
            font-weight: 500;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: color 0.3s ease;
        }

        .advanced-toggle:hover {
            color: var(--accent-secondary);
        }

        .advanced-options {
            display: none;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border-color);
        }

        .advanced-options.show {
            display: grid;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-left: 0;
            }

            .top-header {
                padding: 1rem;
            }

            .header-title {
                font-size: 1.5rem;
            }

            .content {
                padding: 1rem;
            }

            .search-form {
                grid-template-columns: 1fr;
            }

            .filter-tags {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="index.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="search-rooms.php" class="nav-link active">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="my-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        My Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">Search Rooms</h1>
                <div class="header-actions">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($username, 0, 1)); ?>
                        </div>
                        <span>Hello, <?php echo htmlspecialchars($username); ?></span>
                    </div>
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                <!-- Search Section -->
                <div class="search-section">
                    <h2 class="section-title">
                        <i class="fas fa-search"></i>
                        Find Available Rooms
                    </h2>
                    
                    <!-- Quick Filter Tags -->
                    <div class="filter-tags">
                        <div class="filter-tag active" onclick="setQuickFilter('all')">All Rooms</div>
                        <div class="filter-tag" onclick="setQuickFilter('lab')">Labs Only</div>
                        <div class="filter-tag" onclick="setQuickFilter('classroom')">Classrooms</div>
                        <div class="filter-tag" onclick="setQuickFilter('interactive')">Interactive</div>
                        <div class="filter-tag" onclick="setQuickFilter('morning')">Morning Slots</div>
                        <div class="filter-tag" onclick="setQuickFilter('afternoon')">Afternoon Slots</div>
                    </div>

                    <form method="POST" class="search-form" id="searchForm">
                        <div class="form-group">
                            <label class="form-label">Block</label>
                            <select name="block" required class="form-select" id="blockSelect">
                                <option value="">Select Block</option>
                                <option value="A">Block A</option>
                                <option value="B">Block B</option>
                                <option value="C">Block C</option>
                                <option value="D">Block D</option>
                                <option value="E">Block E</option>
                                <option value="F">Block F</option>
                                <option value="M">Block M (Interactive)</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Type</label>
                            <select name="type" required class="form-select" id="typeSelect">
                                <option value="">Select Type</option>
                                <option value="lab">Lab</option>
                                <option value="classroom">Classroom</option>
                                <option value="interactive">Interactive</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Date</label>
                            <select name="date" required class="form-select">
                                <?php
                                for ($i = 0; $i < 7; $i++) {
                                    $date_value = date('Y-m-d', strtotime("+$i days"));
                                    $date_display = date('d M Y (l)', strtotime("+$i days"));
                                    $today_label = ($i == 0) ? ' - Today' : (($i == 1) ? ' - Tomorrow' : '');
                                    echo "<option value='$date_value'>$date_display$today_label</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Time Slot</label>
                            <select name="time" required class="form-select" id="timeSelect">
                                <optgroup label="2 Hour Slots">
                                    <option value="08:00-10:00">08:00 – 10:00</option>
                                    <option value="09:00-11:00">09:00-11:00</option>
                                    <option value="10:30-12:30">10:30-12:30</option>
                                    <option value="11:30-13:30">11:30-13:30</option>
                                    <option value="13:30-15:30">13:30-15:30</option>
                                    <option value="14:30-16:30">14:30-16:30</option>
                                </optgroup>
                               
                            </select>
                        </div>

                        <button type="button" class="advanced-toggle" onclick="toggleAdvanced()">
                            <i class="fas fa-cog"></i>
                            Advanced Options
                        </button>

                        <div class="advanced-options" id="advancedOptions">
                            <div class="form-group">
                                <label class="form-label">Minimum Capacity</label>
                                <select name="capacity" class="form-select">
                                    <option value="">Any Capacity</option>
                                    <?php foreach ($capacities as $capacity): ?>
                                        <option value="<?php echo $capacity; ?>"><?php echo $capacity; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" class="search-btn">
                            <i class="fas fa-search"></i>
                            Search Rooms
                        </button>
                    </form>
                </div>

                <!-- Dashboard Grid -->
                <div class="dashboard-grid">
                    <div class="card">
                        <h3 class="card-title">
                            <i class="fas fa-fire"></i>
                            Popular Labs
                        </h3>
                        <?php if (!empty($popular_labs)): ?>
                            <?php foreach ($popular_labs as $lab): ?>
                                <div class="popular-lab">
                                    <div class="lab-info">
                                        <div class="lab-icon">
                                            <?php echo substr($lab['lab'], 0, 1); ?>
                                        </div>
                                        <div>
                                            <div class="lab-name"><?php echo htmlspecialchars($lab['lab']); ?></div>
                                        </div>
                                    </div>
                                    <div class="lab-count"><?php echo $lab['booking_count']; ?> bookings</div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="color: var(--text-muted); text-align: center; padding: 2rem;">No booking data available yet.</p>
                        <?php endif; ?>
                    </div>

                    <div class="card">
                        <h3 class="card-title">
                            <i class="fas fa-history"></i>
                            Quick Search
                        </h3>
                        <?php foreach ($recent_searches as $search): ?>
                            <div class="recent-search" onclick="applyQuickSearch('<?php echo $search['block']; ?>', '<?php echo $search['type']; ?>', '<?php echo $search['time']; ?>')">
                                <div class="search-details">
                                    <span>Block <?php echo $search['block']; ?> - <?php echo ucfirst($search['type']); ?></span>
                                    <span class="search-block"><?php echo $search['time']; ?></span>
                                </div>
                                <div class="search-meta">Click to apply this search</div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function setQuickFilter(type) {
            // Remove active class from all tags
            document.querySelectorAll('.filter-tag').forEach(tag => {
                tag.classList.remove('active');
            });
            
            // Add active class to clicked tag
            event.target.classList.add('active');
            
            const typeSelect = document.getElementById('typeSelect');
            const timeSelect = document.getElementById('timeSelect');
            
            switch(type) {
                case 'lab':
                    typeSelect.value = 'lab';
                    break;
                case 'classroom':
                    typeSelect.value = 'classroom';
                    break;
                case 'interactive':
                    typeSelect.value = 'interactive';
                    break;
                case 'morning':
                    timeSelect.value = '08:30-10:30';
                    break;
                case 'afternoon':
                    timeSelect.value = '14:00-16:00';
                    break;
                case 'all':
                default:
                    typeSelect.value = '';
                    timeSelect.value = '';
                    break;
            }
        }

        function toggleAdvanced() {
            const options = document.getElementById('advancedOptions');
            const toggle = document.querySelector('.advanced-toggle i');
            
            if (options.classList.contains('show')) {
                options.classList.remove('show');
                toggle.className = 'fas fa-cog';
            } else {
                options.classList.add('show');
                toggle.className = 'fas fa-times';
            }
        }

        function applyQuickSearch(block, type, time) {
            document.getElementById('blockSelect').value = block;
            document.getElementById('typeSelect').value = type;
            document.getElementById('timeSelect').value = time;
            
            // Highlight the form briefly
            const form = document.getElementById('searchForm');
            form.style.boxShadow = '0 0 20px rgba(0, 212, 255, 0.3)';
            setTimeout(() => {
                form.style.boxShadow = '';
            }, 1000);
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>
