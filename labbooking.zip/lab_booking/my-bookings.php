<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// ================================================================
// == FIXED: Handle booking cancellation using Hard Delete       ==
// ================================================================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancel_booking'])) {
    $booking_id = (int)$_POST['booking_id'];
    $delete_reason = $conn->real_escape_string($_POST['delete_reason']);

    // Find the booking to make sure it belongs to the user and is active
    $booking_result = $conn->query("SELECT * FROM bookings WHERE id=$booking_id AND username='$username' AND deleted=0");
    
    if ($booking_result && $booking_result->num_rows > 0) {
        $booking = $booking_result->fetch_assoc();
        
        // 1. Archive to deleted_bookings
        $conn->query("INSERT INTO deleted_bookings (lab, day, start_time, end_time, block, username, booking_date, reason, delete_reason)
                      VALUES ('{$booking['lab']}', '{$booking['day']}', '{$booking['start_time']}', '{$booking['end_time']}', '{$booking['block']}',
                              '{$booking['username']}', '{$booking['booking_date']}', '{$booking['reason']}', '$delete_reason')");
        
        // 2. HARD DELETE from bookings table
        $conn->query("DELETE FROM bookings WHERE id=$booking_id");
        
        echo "<script>alert('Booking has been cancelled.'); window.location='my-bookings.php';</script>";
        exit;
    }
}

// ============================================================================
// == UPDATED: Fetch only active (non-deleted) bookings for the current view ==
// ============================================================================
$current_bookings = $conn->query("SELECT * FROM bookings WHERE username='$username' AND deleted = 0 ORDER BY booking_date DESC");

// These queries are now correct because of our previous fixes
$booking_history = $conn->query("SELECT * FROM booked_labs WHERE username='$username' ORDER BY booking_date DESC");
$cancelled_bookings = $conn->query("SELECT * FROM deleted_bookings WHERE username='$username' ORDER BY deleted_at DESC");

// Get statistics
$total_bookings = $conn->query("SELECT COUNT(*) as count FROM booked_labs WHERE username='$username'")->fetch_assoc()['count'];
$active_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE username='$username' AND deleted=0")->fetch_assoc()['count'];
$cancelled_count = $conn->query("SELECT COUNT(*) as count FROM deleted_bookings WHERE username='$username'")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-tertiary);
            border-radius: 12px;
            border: 1px solid var(--border-color);
        }

        .user-avatar {
            width: 2.5rem;
            height: 2.5rem;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card.blue {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
        }

        .stat-card.green {
            background: linear-gradient(135deg, #10b981, #059669);
        }

        .stat-card.red {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }

        .stat-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.9rem;
            font-weight: 500;
        }

        .stat-icon {
            width: 3rem;
            height: 3rem;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: white;
            margin-bottom: 0.5rem;
        }

        .stat-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.85rem;
        }

        /* Tabs */
        .tabs {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            overflow: hidden;
        }

        .tab-header {
            display: flex;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
        }

        .tab-btn {
            flex: 1;
            padding: 1rem 2rem;
            background: none;
            border: none;
            color: var(--text-secondary);
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }

        .tab-btn.active {
            color: var(--accent-primary);
            background: var(--bg-tertiary);
        }

        .tab-btn.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: var(--accent-primary);
        }

        .tab-content {
            padding: 2rem;
            min-height: 400px;
        }

        .tab-pane {
            display: none;
        }

        .tab-pane.active {
            display: block;
        }

        /* Booking Cards */
        .booking-card {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--accent-primary);
            transition: all 0.3s ease;
        }

        .booking-card:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .booking-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .booking-lab {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .booking-lab i {
            color: var(--accent-primary);
        }

        .booking-block {
            background: var(--accent-primary);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .booking-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .booking-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-secondary);
        }

        .booking-detail i {
            color: var(--accent-primary);
            width: 1rem;
        }

        .booking-reason {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            color: var(--text-secondary);
            font-style: italic;
        }

        .booking-meta {
            color: var(--text-muted);
            font-size: 0.85rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .actions-form {
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .cancel-input {
            flex: 1;
            min-width: 250px;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
        }

        .action-btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }
        
        .edit-btn {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            color: white;
        }

        .cancel-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
        }

        .action-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .no-bookings {
            text-align: center;
            color: var(--text-muted);
            padding: 3rem;
            background: var(--bg-tertiary);
            border-radius: 16px;
            border: 1px dashed var(--border-color);
        }

        .no-bookings i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--text-muted);
            opacity: 0.5;
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="index.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="my-bookings.php" class="nav-link active">
                        <i class="fas fa-calendar"></i>
                        My Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">My Bookings</h1>
                <div class="header-actions">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($username, 0, 1)); ?>
                        </div>
                        <span>Hello, <?php echo htmlspecialchars($username); ?></span>
                    </div>
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card blue">
                        <div class="stat-header">
                            <div>
                                <div class="stat-title">Total Bookings</div>
                                <div class="stat-value"><?php echo $total_bookings; ?></div>
                                <div class="stat-subtitle">All time bookings</div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card green">
                        <div class="stat-header">
                            <div>
                                <div class="stat-title">Active Bookings</div>
                                <div class="stat-value"><?php echo $active_bookings; ?></div>
                                <div class="stat-subtitle">Currently active</div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card red">
                        <div class="stat-header">
                            <div>
                                <div class="stat-title">Cancelled</div>
                                <div class="stat-value"><?php echo $cancelled_count; ?></div>
                                <div class="stat-subtitle">Cancelled bookings</div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-times-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tabs -->
                <div class="tabs">
                    <div class="tab-header">
                        <button class="tab-btn active" onclick="showTab('current')">
                            <i class="fas fa-calendar-check"></i>
                            Current Bookings
                        </button>
                        <button class="tab-btn" onclick="showTab('history')">
                            <i class="fas fa-history"></i>
                            Booking History
                        </button>
                        <button class="tab-btn" onclick="showTab('cancelled')">
                            <i class="fas fa-times-circle"></i>
                            Cancelled Bookings
                        </button>
                    </div>

                    <!-- Current Bookings Tab -->
                    <div class="tab-content">
                        <div id="current" class="tab-pane active">
                            <?php if ($current_bookings && $current_bookings->num_rows > 0): ?>
                                <?php while ($booking = $current_bookings->fetch_assoc()): ?>
                                    <div class="booking-card">
                                        <div class="booking-header">
                                            <div class="booking-lab">
                                                <i class="fas fa-flask"></i>
                                                <?php echo htmlspecialchars($booking['lab']); ?>
                                            </div>
                                            <div class="booking-block">Block <?php echo htmlspecialchars($booking['block']); ?></div>
                                        </div>
                                        
                                        <div class="booking-details">
                                            <div class="booking-detail">
                                                <i class="fas fa-calendar"></i>
                                                <span><?php echo htmlspecialchars($booking['day']); ?></span>
                                            </div>
                                            <div class="booking-detail">
                                                <i class="fas fa-clock"></i>
                                                <span><?php echo $booking['start_time'] . " – " . $booking['end_time']; ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="booking-reason">
                                            <strong>Reason:</strong> <?php echo htmlspecialchars($booking['reason']); ?>
                                        </div>
                                        
                                        <div class="booking-meta">
                                            <i class="fas fa-info-circle"></i>
                                            Booked on: <?php echo date('d M Y, h:i A', strtotime($booking['booking_date'])); ?>
                                        </div>
                                        
                                        <form method="POST" class="actions-form">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                            <input type="text" name="delete_reason" placeholder="Reason for cancellation" required class="cancel-input">
                                            
                                            <a href="edit-booking.php?id=<?php echo $booking['id']; ?>" class="action-btn edit-btn">
                                                <i class="fas fa-edit"></i>
                                                Edit
                                            </a>
                                            
                                            <button type="submit" name="cancel_booking" class="action-btn cancel-btn">
                                                <i class="fas fa-times"></i>
                                                Cancel
                                            </button>
                                        </form>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="no-bookings">
                                    <i class="fas fa-calendar-times"></i>
                                    <h3>No Current Bookings</h3>
                                    <p>You don't have any active bookings at the moment.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Booking History Tab -->
                        <div id="history" class="tab-pane">
                            <?php if ($booking_history && $booking_history->num_rows > 0): ?>
                                <?php while ($booking = $booking_history->fetch_assoc()): ?>
                                    <div class="booking-card">
                                        <div class="booking-header">
                                            <div class="booking-lab">
                                                <i class="fas fa-flask"></i>
                                                <?php echo htmlspecialchars($booking['lab']); ?>
                                            </div>
                                            <div class="booking-block">Block <?php echo htmlspecialchars($booking['block']); ?></div>
                                        </div>
                                        <div class="booking-details">
                                            <div class="booking-detail">
                                                <i class="fas fa-calendar"></i>
                                                <span><?php echo htmlspecialchars($booking['day']); ?></span>
                                            </div>
                                            <div class="booking-detail">
                                                <i class="fas fa-clock"></i>
                                                <span><?php echo $booking['start_time'] . " – " . $booking['end_time']; ?></span>
                                            </div>
                                        </div>
                                        <div class="booking-reason">
                                            <strong>Reason:</strong> <?php echo htmlspecialchars($booking['reason']); ?>
                                        </div>
                                        <div class="booking-meta">
                                            <i class="fas fa-check-circle"></i>
                                            Completed on: <?php echo date('d M Y, h:i A', strtotime($booking['booking_date'])); ?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="no-bookings">
                                    <i class="fas fa-history"></i>
                                    <h3>No Booking History</h3>
                                    <p>You haven't completed any bookings yet.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Cancelled Bookings Tab -->
                        <div id="cancelled" class="tab-pane">
                            <?php if ($cancelled_bookings && $cancelled_bookings->num_rows > 0): ?>
                                <?php while ($booking = $cancelled_bookings->fetch_assoc()): ?>
                                    <div class="booking-card" style="border-left-color: var(--accent-danger);">
                                        <div class="booking-header">
                                            <div class="booking-lab">
                                                <i class="fas fa-flask"></i>
                                                <?php echo htmlspecialchars($booking['lab']); ?>
                                            </div>
                                            <div class="booking-block" style="background: var(--accent-danger);">Block <?php echo htmlspecialchars($booking['block']); ?></div>
                                        </div>
                                        <div class="booking-details">
                                            <div class="booking-detail">
                                                <i class="fas fa-calendar"></i>
                                                <span><?php echo htmlspecialchars($booking['day']); ?></span>
                                            </div>
                                            <div class="booking-detail">
                                                <i class="fas fa-clock"></i>
                                                <span><?php echo $booking['start_time'] . " – " . $booking['end_time']; ?></span>
                                            </div>
                                        </div>
                                        <div class="booking-reason">
                                            <strong>Original Reason:</strong> <?php echo htmlspecialchars($booking['reason']); ?>
                                        </div>
                                        <div class="booking-reason" style="border-color: var(--accent-danger);">
                                            <strong>Cancellation Reason:</strong> <?php echo htmlspecialchars($booking['delete_reason']); ?>
                                        </div>
                                        <div class="booking-meta">
                                            <i class="fas fa-times-circle"></i>
                                            Cancelled on: <?php echo date('d M Y, h:i A', strtotime($booking['deleted_at'])); ?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="no-bookings">
                                    <i class="fas fa-smile"></i>
                                    <h3>No Cancelled Bookings</h3>
                                    <p>You haven't cancelled any bookings. Great job!</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function showTab(tabName) {
            // Hide all tab panes
            const panes = document.querySelectorAll('.tab-pane');
            panes.forEach(pane => pane.classList.remove('active'));
            
            // Remove active class from all buttons
            const buttons = document.querySelectorAll('.tab-btn');
            buttons.forEach(btn => btn.classList.remove('active'));
            
            // Show selected tab pane
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to clicked button
            event.target.classList.add('active');
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>
