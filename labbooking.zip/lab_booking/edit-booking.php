<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Authentication check
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];
$message = '';
$message_type = '';
$booking_data = null;

// Check if a booking ID is provided in the URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: my-bookings.php"); // Redirect if no ID is provided
    exit;
}

$booking_id = (int)$_GET['id'];

// Fetch the booking details, ensuring it belongs to the logged-in user and is not deleted
$stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ? AND username = ? AND deleted = 0");
$stmt->bind_param("is", $booking_id, $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $booking_data = $result->fetch_assoc();
} else {
    // If booking not found or doesn't belong to user, redirect
    header("Location: my-bookings.php");
    exit;
}
$stmt->close();


// Handle the form submission for updating the booking
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_booking'])) {
    $new_reason = $conn->real_escape_string($_POST['reason']);

    if (!empty($new_reason)) {
        $stmt_update = $conn->prepare("UPDATE bookings SET reason = ? WHERE id = ? AND username = ?");
        $stmt_update->bind_param("sis", $new_reason, $booking_id, $username);
        
        if ($stmt_update->execute()) {
            $message = "Booking reason updated successfully!";
            $message_type = "success";
            // Refresh data to show updated reason in the form
            $booking_data['reason'] = $new_reason;
        } else {
            $message = "Error updating booking: " . $conn->error;
            $message_type = "error";
        }
        $stmt_update->close();
    } else {
        $message = "Reason cannot be empty.";
        $message_type = "error";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Booking - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--bg-tertiary);
            color: var(--accent-primary);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
        }

        .back-link:hover {
            background: var(--accent-primary);
            color: white;
        }

        .content {
            padding: 2rem;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
        }

        .alert.success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: var(--accent-success);
        }

        .alert.error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--accent-danger);
        }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
        }

        .card-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .card-title i {
            color: var(--accent-primary);
        }

        .booking-summary {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .booking-lab {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1rem;
        }
        
        .booking-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        .booking-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-secondary);
        }

        .booking-detail i {
            color: var(--accent-primary);
            width: 1rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .form-input {
            width: 100%;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 1rem;
        }
        
        .form-btn {
            width: 100%;
            padding: 0.75rem;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .form-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="index.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="my-bookings.php" class="nav-link active">
                        <i class="fas fa-calendar"></i>
                        My Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">Edit Booking</h1>
                <div class="header-actions">
                    <a href="my-bookings.php" class="back-link">
                        <i class="fas fa-arrow-left"></i>
                        Back to My Bookings
                    </a>
                </div>
            </header>

            <div class="content">
                <?php if ($message): ?>
                    <div class="alert <?php echo $message_type; ?>">
                        <i class="fas <?php echo $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'; ?>"></i>
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>

                <?php if ($booking_data): ?>
                <div class="card">
                    <h2 class="card-title">
                        <i class="fas fa-info-circle"></i>
                        Booking Details
                    </h2>

                    <div class="booking-summary">
                        <div class="booking-lab">
                            <i class="fas fa-flask"></i>
                            <?php echo htmlspecialchars($booking_data['lab']); ?>
                            <span style="font-size: 0.9rem; color: var(--text-muted); margin-left: 0.5rem;">(Block <?php echo htmlspecialchars($booking_data['block']); ?>)</span>
                        </div>
                        <div class="booking-details">
                            <div class="booking-detail">
                                <i class="fas fa-calendar"></i>
                                <span><?php echo htmlspecialchars($booking_data['day']); ?></span>
                            </div>
                            <div class="booking-detail">
                                <i class="fas fa-clock"></i>
                                <span><?php echo $booking_data['start_time'] . " – " . $booking_data['end_time']; ?></span>
                            </div>
                        </div>
                    </div>

                    <form method="POST">
                        <input type="hidden" name="booking_id" value="<?php echo $booking_data['id']; ?>">
                        <div class="form-group">
                            <label for="reason" class="form-label">Reason for Booking</label>
                            <textarea name="reason" id="reason" class="form-input" rows="4" required><?php echo htmlspecialchars($booking_data['reason']); ?></textarea>
                        </div>
                        <button type="submit" name="update_booking" class="form-btn">
                            <i class="fas fa-save"></i>
                            Save Changes
                        </button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
