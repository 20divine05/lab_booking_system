<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Authentication check
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// ==================================================================
// == FIXED: Automatic cleanup for expired bookings (Hard Delete)  ==
// ==================================================================
$current_day_for_cleanup = date('l');
$current_time_for_cleanup = date('H:i:s');

// Find expired bookings for today that are not yet deleted
$expired_sql = "SELECT * FROM bookings WHERE day = ? AND end_time <= ? AND deleted = 0";
$stmt_expired = $conn->prepare($expired_sql);
$stmt_expired->bind_param("ss", $current_day_for_cleanup, $current_time_for_cleanup);
$stmt_expired->execute();
$expired_result = $stmt_expired->get_result();

if ($expired_result->num_rows > 0) {
    while ($booking = $expired_result->fetch_assoc()) {
        // 1. Archive to booked_labs (our history table)
        $archive_sql = "INSERT INTO booked_labs (lab, day, start_time, end_time, block, username, booking_date, reason, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_archive = $conn->prepare($archive_sql);
        $stmt_archive->bind_param("sssssssss", $booking['lab'], $booking['day'], $booking['start_time'], $booking['end_time'], $booking['block'], $booking['username'], $booking['booking_date'], $booking['reason'], $booking['phone']);
        $stmt_archive->execute();
        $stmt_archive->close();

        // 2. HARD DELETE from the active bookings table
        $delete_sql = "DELETE FROM bookings WHERE id = ?";
        $stmt_delete = $conn->prepare($delete_sql);
        $stmt_delete->bind_param("i", $booking['id']);
        $stmt_delete->execute();
        $stmt_delete->close();
    }
}
$stmt_expired->close();


// ================================================================
// == FIXED: Handle booking cancellation using Hard Delete       ==
// ================================================================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancel_booking'])) {
    $booking_id = (int)$_POST['booking_id'];
    $delete_reason = $conn->real_escape_string($_POST['delete_reason']);

    $booking_result = $conn->query("SELECT * FROM bookings WHERE id=$booking_id AND username='$username' AND deleted=0");
    
    if ($booking_result && $booking_result->num_rows > 0) {
        $booking = $booking_result->fetch_assoc();
        
        // 1. Archive to deleted_bookings
        $conn->query("INSERT INTO deleted_bookings (lab, day, start_time, end_time, block, username, booking_date, reason, delete_reason)
                      VALUES ('{$booking['lab']}', '{$booking['day']}', '{$booking['start_time']}', '{$booking['end_time']}', '{$booking['block']}',
                              '{$booking['username']}', '{$booking['booking_date']}', '{$booking['reason']}', '$delete_reason')");
        
        // 2. HARD DELETE from the active bookings table
        $conn->query("DELETE FROM bookings WHERE id=$booking_id");
        
        echo "<script>alert('Booking has been cancelled.'); window.location='index.php';</script>";
        exit;
    }
}

// ============================================================================
// == UPDATED: Fetch only active (non-deleted) bookings for the user's view ==
// ============================================================================
$user_bookings_result = $conn->query("SELECT * FROM bookings WHERE username='$username' AND deleted = 0 ORDER BY booking_date DESC");

// Fetch recently made bookings for notification
$recent_bookings = [];
$time_2_hours_ago = date('Y-m-d H:i:s', strtotime('-2 hours'));

// This query should also only check active bookings
$recent_sql = "SELECT lab, booking_date FROM bookings 
               WHERE username = '$username' AND deleted = 0
               AND booking_date >= '$time_2_hours_ago' 
               ORDER BY booking_date DESC";
$recent_result = $conn->query($recent_sql);
if ($recent_result && $recent_result->num_rows > 0) {
    while ($row = $recent_result->fetch_assoc()) {
        $recent_bookings[] = $row;
    }
}

// FIXED: Get available capacities with proper display
$capacities = [30, 45, 60]; // Fixed capacity values

// Fetch data for "At a Glance" section
$total_labs = $conn->query("SELECT COUNT(*) as count FROM labs")->fetch_assoc()['count'];
// This now correctly reflects history
$your_total_bookings = $conn->query("SELECT COUNT(*) as count FROM booked_labs WHERE username='$username'")->fetch_assoc()['count'];

$live_bookings = [];
$current_day_name = date('l');
$current_time = date('H:i:s');
// This query now correctly checks non-deleted bookings
$live_sql = "SELECT lab, end_time, username FROM bookings WHERE day = '$current_day_name' AND start_time <= '$current_time' AND end_time > '$current_time' AND deleted = 0 ORDER BY end_time ASC";
$live_result = $conn->query($live_sql);
if($live_result && $live_result->num_rows > 0) {
    while($row = $live_result->fetch_assoc()){
        $live_bookings[] = $row;
    }
}

// Fetch user's most frequently booked labs (correctly from history)
$frequent_labs = [];
$frequent_sql = "SELECT lab, COUNT(lab) as count 
                 FROM booked_labs 
                 WHERE username = '$username' 
                 GROUP BY lab 
                 ORDER BY count DESC 
                 LIMIT 3";
$frequent_result = $conn->query($frequent_sql);
if ($frequent_result && $frequent_result->num_rows > 0) {
    while ($row = $frequent_result->fetch_assoc()) {
        $frequent_labs[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-tertiary);
            border-radius: 12px;
            border: 1px solid var(--border-color);
        }

        .user-avatar {
            width: 2.5rem;
            height: 2.5rem;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Search Section */
        .search-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title i {
            color: var(--accent-primary);
        }

        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            align-items: end;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .form-select,
        .form-input {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-select:focus,
        .form-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-select option {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .search-btn {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            height: fit-content;
        }

        .search-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        /* Dashboard Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .card:hover {
            box-shadow: var(--shadow-lg);
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .card-title i {
            color: var(--accent-primary);
        }

        /* Stats Items */
        .stat-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .stat-item:last-child {
            border-bottom: none;
        }

        .stat-label {
            color: var(--text-secondary);
        }

        .stat-value {
            color: var(--accent-primary);
            font-weight: 600;
            font-size: 1.1rem;
        }

        /* Live Bookings */
        .live-booking {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1rem;
            border-left: 4px solid var(--accent-success);
        }

        .live-booking:last-child {
            margin-bottom: 0;
        }

        .booking-lab {
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
        }

        .booking-user {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Frequent Labs */
        .frequent-lab {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .frequent-lab:last-child {
            border-bottom: none;
        }

        .lab-name {
            color: var(--text-primary);
            font-weight: 500;
        }

        .lab-count {
            background: var(--bg-tertiary);
            color: var(--accent-primary);
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        /* Recent Notifications */
        .notification-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            overflow: hidden;
        }

        .notification-header {
            background: linear-gradient(135deg, var(--accent-success), #059669);
            color: white;
            padding: 1rem 1.5rem;
            font-weight: 600;
        }

        .notification-item {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-lab {
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
        }

        .notification-time {
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        /* Current Bookings */
        .booking-card {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--accent-primary);
            transition: all 0.3s ease;
        }

        .booking-card:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .booking-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .booking-lab-name {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .booking-lab-name i {
            color: var(--accent-primary);
        }

        .booking-block {
            background: var(--accent-primary);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .booking-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .booking-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-secondary);
        }

        .booking-detail i {
            color: var(--accent-primary);
            width: 1rem;
        }

        .booking-reason {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            color: var(--text-secondary);
            font-style: italic;
        }

        .booking-meta {
            color: var(--text-muted);
            font-size: 0.85rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .cancel-form {
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .cancel-input {
            flex: 1;
            min-width: 250px;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
        }

        .cancel-input:focus {
            outline: none;
            border-color: var(--accent-danger);
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
        }

        .cancel-input::placeholder {
            color: var(--text-muted);
        }

        .cancel-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .cancel-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .no-bookings {
            text-align: center;
            color: var(--text-muted);
            padding: 3rem;
            background: var(--bg-tertiary);
            border-radius: 16px;
            border: 1px dashed var(--border-color);
        }

        .no-bookings i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--text-muted);
            opacity: 0.5;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-left: 0;
            }

            .top-header {
                padding: 1rem;
            }

            .header-title {
                font-size: 1.5rem;
            }

            .content {
                padding: 1rem;
            }

            .search-form {
                grid-template-columns: 1fr;
            }

            .booking-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .booking-details {
                grid-template-columns: 1fr;
            }

            .cancel-form {
                flex-direction: column;
                align-items: stretch;
            }

            .cancel-input {
                min-width: auto;
            }
        }
        .booking-card {
    border: 1px solid #728199;
    padding: 1rem;
    margin: 1rem 0;
    border-radius: 10px;
    background-color: #1e2a4a;
}
.booking-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
}
.booking-details {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
}
.actions-form {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-top: 0.5rem;
}
.cancel-input {
    flex: 1;
    padding: 5px 10px;
    border-radius: 5px;
    border: 1px solid #aaa;
}
.action-btn {
    padding: 5px 10px;
    border-radius: 5px;
    color: white;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
}
.edit-btn {
    background-color: #007bff;
}
.cancel-btn {
    background-color: #dc3545;
    border: none;
}

    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="index.php" class="nav-link active">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="my-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        My Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">Dashboard</h1>
                <div class="header-actions">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($username, 0, 1)); ?>
                        </div>
                        <span>Welcome, <?php echo htmlspecialchars($username); ?></span>
                    </div>
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                <!-- Search Section -->
                <div class="search-section">
                    <h2 class="section-title">
                        <i class="fas fa-search"></i>
                        Search for Available Rooms
                    </h2>
                    <form method="POST" action="search_available.php" class="search-form">
                        <div class="form-group">
                            <label class="form-label">Block</label>
                            <select name="block" required class="form-select">
                                <option value="">Select Block</option>
                                <option value="A">Block A</option>
                                <option value="B">Block B</option>
                                <option value="C">Block C</option>
                                <option value="D">Block D</option>
                                <option value="E">Block E</option>
                                <option value="F">Block F</option>
                                <option value="M">Block M (Interactive)</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Type</label>
                            <select name="type" required class="form-select">
                                <option value="">Select Type</option>
                                <option value="lab">Lab</option>
                                <option value="classroom">Classroom</option>
                                <option value="interactive">Interactive</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Date</label>
                            <select name="date" required class="form-select">
                                <?php
                                for ($i = 0; $i < 7; $i++) {
                                    $date_value = date('Y-m-d', strtotime("+$i days"));
                                    $date_display = date('d M Y (l)', strtotime("+$i days"));
                                    $today_label = ($i == 0) ? ' - Today' : (($i == 1) ? ' - Tomorrow' : '');
                                    echo "<option value='$date_value'>$date_display$today_label</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Capacity</label>
                            <select name="capacity" class="form-select">
                                <option value="">Any Capacity</option>
                                <?php foreach ($capacities as $capacity): ?>
                                    <option value="<?php echo $capacity; ?>"><?php echo $capacity; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Time Slot</label>
                            <select name="time" required class="form-select">
                                <optgroup label="2 Hour Slots">
                                    <option value="08:00-10:00">08:00 – 10:00</option>
                                    <option value="09:00-11:00">09:00-11:00</option>
                                    <option value="10:30-12:30">10:30-12:30</option>
                                    <option value="11:30-13:30">11:30-13:30</option>
                                    <option value="13:30-15:30">13:30-15:30</option>
                                    <option value="14:30-16:30">14:30-16:30</option>
                                </optgroup>
                                
                            </select>
                        </div>
                        
                        <button type="submit" class="search-btn">
                            <i class="fas fa-search"></i>
                            Search Rooms
                        </button>
                    </form>
                </div>

                <!-- Dashboard Grid -->
                <div class="dashboard-grid">
                    <div class="card">
                        <h3 class="card-title">
                            <i class="fas fa-chart-line"></i>
                            Dashboard at a Glance
                        </h3>
                        <div class="stat-item">
                            <span class="stat-label">Total Rooms Available</span>
                            <span class="stat-value"><?php echo $total_labs; ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Your Total Bookings</span>
                            <span class="stat-value"><?php echo $your_total_bookings; ?></span>
                        </div>
                        
                        <h4 style="margin: 2rem 0 1rem 0; color: var(--text-primary); font-size: 1.1rem;">
                            <i class="fas fa-clock" style="color: var(--accent-warning); margin-right: 0.5rem;"></i>
                            What's Happening Now?
                        </h4>
                        <?php if (!empty($live_bookings)): ?>
                            <?php foreach ($live_bookings as $booking): ?>
                                <div class="live-booking">
                                    <div class="booking-lab"><?php echo htmlspecialchars($booking['lab']); ?></div>
                                    <div class="booking-user">
                                        In use by <strong><?php echo htmlspecialchars($booking['username']); ?></strong> 
                                        until <?php echo date('h:i A', strtotime($booking['end_time'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="live-booking" style="border-left-color: var(--text-muted);">
                                <div class="booking-user">No labs are currently in use.</div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div>
                        <!-- Frequent Labs -->
                        <div class="card" style="margin-bottom: 1.5rem;">
                            <h3 class="card-title">
                                <i class="fas fa-star"></i>
                                Your Frequent Labs
                            </h3>
                            <?php if (!empty($frequent_labs)): ?>
                                <?php foreach ($frequent_labs as $lab): ?>
                                    <div class="frequent-lab">
                                        <div class="lab-name"><?php echo htmlspecialchars($lab['lab']); ?></div>
                                        <div class="lab-count"><?php echo $lab['count']; ?> times</div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="color: var(--text-muted); text-align: center; padding: 1rem;">No booking history yet.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Recent Bookings Notification -->
                        <?php if (!empty($recent_bookings)): ?>
                        <div class="notification-card">
                            <div class="notification-header">
                                <i class="fas fa-bell"></i>
                                Recent Bookings
                            </div>
                            <?php foreach ($recent_bookings as $booking): ?>
                                <div class="notification-item">
                                    <div class="notification-lab"><?php echo htmlspecialchars($booking['lab']); ?></div>
                                    <div class="notification-time">
                                        Booked at <?php echo date('h:i A', strtotime($booking['booking_date'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Current Bookings Section -->
<div class="card" style="margin-top: 2rem;">
    <h3 class="card-title">
        <i class="fas fa-calendar-check"></i>
        Your Current Bookings
    </h3>

    <?php if ($user_bookings_result && $user_bookings_result->num_rows > 0): ?>
        <?php while ($booking = $user_bookings_result->fetch_assoc()): ?>
            <div class="booking-card">
                <div class="booking-header">
                    <div class="booking-lab">
                        <i class="fas fa-flask"></i>
                        <?php echo htmlspecialchars($booking['lab']); ?>
                    </div>
                    <div class="booking-block">
                        Block <?php echo htmlspecialchars($booking['block']); ?>
                    </div>
                </div>

                <div class="booking-details">
                    <div class="booking-detail">
                        <i class="fas fa-calendar"></i>
                        <span><?php echo htmlspecialchars($booking['day']); ?></span>
                    </div>
                    <div class="booking-detail">
                        <i class="fas fa-clock"></i>
                        <span><?php echo $booking['start_time'] . " – " . $booking['end_time']; ?></span>
                    </div>
                </div>

                <div class="booking-reason">
                    <strong>Reason:</strong> <?php echo htmlspecialchars($booking['reason']); ?>
                </div>

                <div class="booking-meta">
                    <i class="fas fa-info-circle"></i>
                    Booked on: <?php echo date('d M Y, h:i A', strtotime($booking['booking_date'])); ?>
                </div>

                <form method="POST" class="actions-form">
                    <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                    <input type="text" name="delete_reason" placeholder="Reason for cancellation" required class="cancel-input">

                    <a href="edit-booking.php?id=<?php echo $booking['id']; ?>" class="action-btn edit-btn">
                        <i class="fas fa-edit"></i>
                        Edit
                    </a>

                    <button type="submit" name="cancel_booking" class="action-btn cancel-btn">
                        <i class="fas fa-times"></i>
                        Cancel
                    </button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="no-bookings">
            <i class="fas fa-calendar-times"></i>
            <h3>No Current Bookings</h3>
            <p>You don't have any active bookings at the moment.</p>
        </div>
    <?php endif; ?>
</div>

            </div>
        </main>
    </div>
</body>
</html>
<?php $conn->close(); ?>
