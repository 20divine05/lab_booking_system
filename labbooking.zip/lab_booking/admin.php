<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Authentication Check
function isAdmin() {
    return isset($_SESSION['username']) && $_SESSION['username'] === 'admin_user';
}

if (!isAdmin()) {
    header("Location: login.php");
    exit();
}

// Handle Logout Request
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Database Connection
$conn = new mysqli("localhost", "root", "", "lab_booking");
if ($conn->connect_error) {
    error_log("DB Connection Error: " . $conn->connect_error);
    die("Database connection failed.");
}

// ==================================================================
// == FIXED: Automatic cleanup for expired bookings (Hard Delete)  ==
// ==================================================================
$current_day_for_cleanup = date('l');
$current_time_for_cleanup = date('H:i:s');

// Find expired bookings for today that are not yet deleted
$expired_sql = "SELECT * FROM bookings WHERE day = ? AND end_time <= ? AND deleted = 0";
$stmt_expired = $conn->prepare($expired_sql);
$stmt_expired->bind_param("ss", $current_day_for_cleanup, $current_time_for_cleanup);
$stmt_expired->execute();
$expired_result = $stmt_expired->get_result();

if ($expired_result->num_rows > 0) {
    while ($booking = $expired_result->fetch_assoc()) {
        // 1. Archive to booked_labs (our history table)
        $archive_sql = "INSERT INTO booked_labs (lab, day, start_time, end_time, block, username, booking_date, reason, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_archive = $conn->prepare($archive_sql);
        $stmt_archive->bind_param("sssssssss", $booking['lab'], $booking['day'], $booking['start_time'], $booking['end_time'], $booking['block'], $booking['username'], $booking['booking_date'], $booking['reason'], $booking['phone']);
        $stmt_archive->execute();
        $stmt_archive->close();

        // 2. HARD DELETE from the active bookings table
        $delete_sql = "DELETE FROM bookings WHERE id = ?";
        $stmt_delete = $conn->prepare($delete_sql);
        $stmt_delete->bind_param("i", $booking['id']);
        $stmt_delete->execute();
        $stmt_delete->close();
    }
}
$stmt_expired->close();


// ======================================================================
// == FIXED: Handle Admin Booking Cancellation with Hard Delete        ==
// ======================================================================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancel_booking'])) {
    $booking_id = (int)$_POST['booking_id'];
    $delete_reason = $conn->real_escape_string($_POST['delete_reason']);

    $booking_result = $conn->query("SELECT * FROM bookings WHERE id=$booking_id AND deleted=0");
    
    if ($booking_result && $booking_result->num_rows > 0) {
        $booking = $booking_result->fetch_assoc();
        
        // 1. Archive to deleted_bookings
        $conn->query("INSERT INTO deleted_bookings (lab, day, start_time, end_time, block, username, booking_date, reason, delete_reason)
                          VALUES ('{$booking['lab']}', '{$booking['day']}', '{$booking['start_time']}', '{$booking['end_time']}', '{$booking['block']}',
                                  '{$booking['username']}', '{$booking['booking_date']}', '{$booking['reason']}', 'Admin: $delete_reason')");
        
        // 2. HARD DELETE from bookings table
        $conn->query("DELETE FROM bookings WHERE id=$booking_id");
        
        echo "<script>alert('Booking has been cancelled by admin.'); window.location='admin.php';</script>";
        exit;
    }
}

// API Endpoint for Fetching Reports
if (isset($_GET['report'])) {
    $reportType = $_GET['report'];
    $data = [];
    $sql = "";

    switch ($reportType) {
        case 'live':
            $sql = "SELECT id, lab, block, day, start_time, end_time, username, reason, booking_date FROM bookings WHERE status='booked' AND deleted=0 ORDER BY booking_date DESC";
            break;
        case 'booked':
            $sql = "SELECT id, lab, block, day, start_time, end_time, username, reason, booking_date FROM booked_labs ORDER BY booking_date DESC";
            break;
        case 'deleted':
            $sql = "SELECT id, lab, block, day, start_time, end_time, username, reason, delete_reason, deleted_at FROM deleted_bookings ORDER BY deleted_at DESC";
            break;
        default:
            echo json_encode(['error' => 'Invalid report type specified.']);
            exit;
    }

    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    } else {
        echo json_encode(['error' => 'Failed to fetch report data.']);
        exit;
    }
    
    header('Content-Type: application/json');
    echo json_encode($data);
    $conn->close();
    exit;
}

// Fetch data for the dashboard
$admin_bookings_result = $conn->query("SELECT * FROM bookings WHERE username='admin_user' AND deleted = 0 ORDER BY booking_date DESC");

$current_day_name = date('l');
$current_time = date('H:i:s');

// FIXED: Get available capacities with proper display
$capacities = [30, 45, 60]; // Fixed capacity values

$live_bookings_result = $conn->query("SELECT * FROM bookings WHERE day = '$current_day_name' AND start_time <= '$current_time' AND end_time > '$current_time' AND deleted = 0 ORDER BY start_time");
$todays_bookings_result = $conn->query("SELECT * FROM bookings WHERE day = '$current_day_name' AND deleted = 0 ORDER BY start_time");
$future_bookings_result = $conn->query("SELECT * FROM bookings WHERE day != '$current_day_name' AND deleted = 0 ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), start_time");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Lab Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1e2a4a;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --text-muted: #6b7280;
            --accent-primary: #00d4ff;
            --accent-secondary: #7c3aed;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #2d3748;
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .logo i {
            color: var(--accent-primary);
            font-size: 1.75rem;
        }

        .admin-badge {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }

        .nav-menu {
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .admin-indicator {
            background: linear-gradient(135deg, var(--accent-warning), #d97706);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .full-access-btn {
            background: linear-gradient(135deg, var(--accent-success), #059669);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .full-access-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .logout-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .content {
            padding: 2rem;
        }

        /* Search Section */
        .search-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title i {
            color: var(--accent-primary);
        }

        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            align-items: end;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .form-select,
        .form-input {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-select:focus,
        .form-input:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-select option {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }

        .search-btn {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            height: fit-content;
        }

        .search-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        /* Custom Time Options */
        .custom-time-div {
            display: none;
            grid-column: 1 / -1;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border-color);
        }

        .custom-time-div.show {
            display: grid;
        }

        /* Admin Bookings */
        .admin-bookings {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .booking-card {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--accent-primary);
            transition: all 0.3s ease;
        }

        .booking-card:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .booking-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .booking-lab {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .booking-lab i {
            color: var(--accent-primary);
        }

        .booking-block {
            background: var(--accent-primary);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .booking-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .booking-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-secondary);
        }

        .booking-detail i {
            color: var(--accent-primary);
            width: 1rem;
        }

        .booking-reason {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            color: var(--text-secondary);
            font-style: italic;
        }

        .booking-meta {
            color: var(--text-muted);
            font-size: 0.85rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .cancel-form {
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .cancel-input {
            flex: 1;
            min-width: 250px;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
        }

        .cancel-input:focus {
            outline: none;
            border-color: var(--accent-danger);
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
        }

        .cancel-input::placeholder {
            color: var(--text-muted);
        }

        .cancel-btn {
            background: linear-gradient(135deg, var(--accent-danger), #dc2626);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .cancel-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        /* Live Overview Grid */
        .overview-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .overview-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .overview-card:hover {
            box-shadow: var(--shadow-lg);
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .card-title i {
            color: var(--accent-primary);
        }

        .overview-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .overview-item:last-child {
            border-bottom: none;
        }

        .item-info {
            flex: 1;
        }

        .item-lab {
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
        }

        .item-details {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .item-status {
            background: var(--accent-success);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        /* Reports Section */
        .reports-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
        }

        .report-controls {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            align-items: center;
        }

        .report-select {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            font-size: 0.9rem;
            min-width: 200px;
        }

        .report-output {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            min-height: 200px;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .report-table th,
        .report-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .report-table th {
            background: var(--bg-primary);
            font-weight: 600;
            color: var(--text-primary);
            text-transform: capitalize;
        }

        .report-table td {
            color: var(--text-secondary);
        }

        .no-bookings {
            text-align: center;
            color: var(--text-muted);
            padding: 3rem;
            background: var(--bg-tertiary);
            border-radius: 16px;
            border: 1px dashed var(--border-color);
        }

        .no-bookings i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--text-muted);
            opacity: 0.5;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .overview-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-left: 0;
            }

            .top-header {
                padding: 1rem;
            }

            .header-title {
                font-size: 1.5rem;
            }

            .content {
                padding: 1rem;
            }

            .search-form {
                grid-template-columns: 1fr;
            }

            .booking-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .booking-details {
                grid-template-columns: 1fr;
            }

            .cancel-form {
                flex-direction: column;
                align-items: stretch;
            }

            .cancel-input {
                min-width: auto;
            }

            .report-controls {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-flask"></i>
                    Lab Booking
                    <span class="admin-badge">ADMIN</span>
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="admin.php" class="nav-link active">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-search-rooms.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        Search Rooms
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-bookings.php" class="nav-link">
                        <i class="fas fa-calendar"></i>
                        All Bookings
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-reports.php" class="nav-link">
                        <i class="fas fa-file-download"></i>
                        Download Reports
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-analytics.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        System Analytics
                    </a>
                </div>
                <div class="nav-item">
                    <a href="admin-manage-users.php" class="nav-link">
                        <i class="fas fa-users-cog"></i>
                        Manage Users
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1 class="header-title">Admin Dashboard</h1>
                <div class="header-actions">
                   
                    <a href="admin_full_access.php" class="full-access-btn">
                        <i class="fas fa-th"></i>
                        Full Access Grid
                    </a>
                    <a href="?logout=true" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </header>

            <div class="content">
                <?php if (isAdmin()): ?>
                    <!-- Search & Book Section -->
                    <div class="search-section">
                        <h2 class="section-title">
                            <i class="fas fa-search"></i>
                            Search & Book Rooms
                        </h2>
                        <form method="POST" action="admin-search-rooms.php" class="search-form">
                            <input type="hidden" name="origin" value="admin">

                            <div class="form-group">
                                <label class="form-label">Block</label>
                                <select name="block" required class="form-select">
                                    <option value="">Select Block</option>
                                    <option value="A">Block A</option>
                                    <option value="B">Block B</option>
                                    <option value="C">Block C</option>
                                    <option value="D">Block D</option>
                                    <option value="E">Block E</option>
                                    <option value="F">Block F</option>
                                    <option value="M">Block M (Interactive)</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Type</label>
                                <select name="type" required class="form-select">
                                    <option value="">Select Type</option>
                                    <option value="lab">Lab</option>
                                    <option value="classroom">Classroom</option>
                                    <option value="interactive">Interactive</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Date</label>
                                <select name="date" required class="form-select">
                                    <?php
                                    for ($i = 0; $i < 7; $i++) {
                                        $date_value = date('Y-m-d', strtotime("+$i days"));
                                        $date_display = date('d M Y (l)', strtotime("+$i days"));
                                        $today_label = ($i == 0) ? ' - Today' : (($i == 1) ? ' - Tomorrow' : '');
                                        echo "<option value='$date_value'>$date_display$today_label</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Time Slot</label>
                                <select name="time" id="time-select" required class="form-select">
                                    <optgroup label="Standard Slots">
                                        <option value="08:00-10:00">08:00 – 10:00</option>
                                    <option value="09:00-11:00">09:00-11:00</option>
                                    <option value="10:30-12:30">10:30-12:30</option>
                                    <option value="11:30-13:30">11:30-13:30</option>
                                    <option value="13:30-15:30">13:30-15:30</option>
                                    <option value="14:30-16:30">14:30-16:30</option>
                                    </optgroup>
                                    
                                    
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Minimum Capacity</label>
                                <select name="capacity" class="form-select">
                                    <option value="">Any Capacity</option>
                                    <?php foreach ($capacities as $capacity): ?>
                                        <option value="<?php echo $capacity; ?>"><?php echo $capacity; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="custom-time-div" id="custom-time-div">
                                <div class="form-group">
                                    <label class="form-label">Start Time</label>
                                    <input type="time" id="start_time" name="start_time" class="form-input">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">End Time</label>
                                    <input type="time" id="end_time" name="end_time" class="form-input">
                                </div>
                            </div>
                            
                            <button type="submit" class="search-btn">
                                <i class="fas fa-search"></i>
                                Search Rooms
                            </button>
                        </form>
                    </div>

                    <!-- Admin Bookings -->
                    <div class="admin-bookings">
                        <h2 class="section-title">
                            <i class="fas fa-user-shield"></i>
                            Your Admin Bookings
                        </h2>
                        <?php if ($admin_bookings_result && $admin_bookings_result->num_rows > 0): ?>
                            <?php while ($booking = $admin_bookings_result->fetch_assoc()): ?>
                                <div class="booking-card">
                                    <div class="booking-header">
                                        <div class="booking-lab">
                                            <i class="fas fa-flask"></i>
                                            <?php echo htmlspecialchars($booking['lab']); ?>
                                        </div>
                                        <div class="booking-block">Block <?php echo htmlspecialchars($booking['block']); ?></div>
                                    </div>
                                    
                                    <div class="booking-details">
                                        <div class="booking-detail">
                                            <i class="fas fa-calendar"></i>
                                            <span><?php echo htmlspecialchars($booking['day']); ?></span>
                                        </div>
                                        <div class="booking-detail">
                                            <i class="fas fa-clock"></i>
                                            <span><?php echo $booking['start_time'] . " – " . $booking['end_time']; ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="booking-reason">
                                        <strong>Reason:</strong> <?php echo htmlspecialchars($booking['reason']); ?>
                                    </div>
                                    
                                    <div class="booking-meta">
                                        <i class="fas fa-info-circle"></i>
                                        Booked on: <?php echo date('d M Y, h:i A', strtotime($booking['booking_date'])); ?>
                                    </div>
                                    
                                    <form method="POST" class="cancel-form">
                                        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                        <input type="text" name="delete_reason" placeholder="Reason for cancellation" required class="cancel-input">
                                        <button type="submit" name="cancel_booking" class="cancel-btn">
                                            <i class="fas fa-times"></i>
                                            Cancel Booking
                                        </button>
                                    </form>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="no-bookings">
                                <i class="fas fa-calendar-times"></i>
                                <h3>No Admin Bookings</h3>
                                <p>You haven't made any bookings directly as an admin.</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Live Overview -->
                    <div class="overview-grid">
                        <div class="overview-card">
                            <h3 class="card-title">
                                <i class="fas fa-broadcast-tower"></i>
                                Live Bookings
                            </h3>
                            <?php if ($live_bookings_result && $live_bookings_result->num_rows > 0): ?>
                                <?php while ($booking = $live_bookings_result->fetch_assoc()): ?>
                                    <div class="overview-item">
                                        <div class="item-info">
                                            <div class="item-lab"><?php echo htmlspecialchars($booking['lab']); ?></div>
                                            <div class="item-details">
                                                by <?php echo htmlspecialchars($booking['username']); ?> 
                                                until <?php echo date('h:i A', strtotime($booking['end_time'])); ?>
                                            </div>
                                        </div>
                                        <div class="item-status">Live</div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="overview-item">
                                    <div class="item-info">
                                        <div class="item-details">No labs are currently in use.</div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="overview-card">
                            <h3 class="card-title">
                                <i class="fas fa-calendar-day"></i>
                                Today's Bookings
                            </h3>
                            <?php if ($todays_bookings_result && $todays_bookings_result->num_rows > 0): ?>
                                <?php while ($booking = $todays_bookings_result->fetch_assoc()): ?>
                                    <div class="overview-item">
                                        <div class="item-info">
                                            <div class="item-lab"><?php echo htmlspecialchars($booking['lab']); ?></div>
                                            <div class="item-details">
                                                <?php echo date('h:i A', strtotime($booking['start_time'])); ?> 
                                                by <?php echo htmlspecialchars($booking['username']); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="overview-item">
                                    <div class="item-info">
                                        <div class="item-details">No bookings for today.</div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="overview-card">
                            <h3 class="card-title">
                                <i class="fas fa-calendar-alt"></i>
                                Future Bookings
                            </h3>
                            <?php if ($future_bookings_result && $future_bookings_result->num_rows > 0): ?>
                                <?php while ($booking = $future_bookings_result->fetch_assoc()): ?>
                                    <div class="overview-item">
                                        <div class="item-info">
                                            <div class="item-lab"><?php echo htmlspecialchars($booking['lab']); ?></div>
                                            <div class="item-details">
                                                on <?php echo htmlspecialchars($booking['day']); ?> 
                                                by <?php echo htmlspecialchars($booking['username']); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="overview-item">
                                    <div class="item-info">
                                        <div class="item-details">No future bookings found.</div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- System Reports -->
                    <div class="reports-section">
                        <h2 class="section-title">
                            <i class="fas fa-chart-line"></i>
                            System Reports
                        </h2>
                        <div class="report-controls">
                            <label class="form-label">Select Report to View:</label>
                            <select id="report-type" class="report-select">
                                <option value="">-- Please Select --</option>
                                <option value="live">Live Bookings</option>
                                <option value="booked">All Bookings (History)</option>
                                <option value="deleted">Cancelled Bookings</option>
                            </select>
                        </div>
                        <div id="report-output" class="report-output">
                            <p style="color: var(--text-muted); text-align: center;">Please select a report from the dropdown menu to view the data.</p>
                        </div>
                    </div>

                <?php else: ?>
                    <div class="no-bookings">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h2>Access Denied</h2>
                        <p>You must be logged in as an administrator to view this page.</p>
                        <a href="login.php" style="color: var(--accent-primary); text-decoration: none; margin-top: 1rem; display: inline-block;">Return to Login</a>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
        <?php if (isAdmin()): ?>
        
        // JS to handle custom time visibility
        const timeSelect = document.getElementById('time-select');
        const customTimeDiv = document.getElementById('custom-time-div');
        const startTimeInput = document.getElementById('start_time');
        const endTimeInput = document.getElementById('end_time');

        timeSelect.addEventListener('change', function() {
            if (this.value === 'custom') {
                customTimeDiv.classList.add('show');
                startTimeInput.required = true;
                endTimeInput.required = true;
            } else {
                customTimeDiv.classList.remove('show');
                startTimeInput.required = false;
                endTimeInput.required = false;
            }
        });

        // JS for reports
        document.getElementById('report-type').addEventListener('change', function () {
            const reportType = this.value;
            const outputDiv = document.getElementById('report-output');
            
            if (!reportType) {
                outputDiv.innerHTML = '<p style="color: var(--text-muted); text-align: center;">Please select a report from the dropdown menu to view the data.</p>';
                return;
            }

            outputDiv.innerHTML = '<p style="color: var(--text-muted); text-align: center;">Loading report...</p>';

            fetch(`admin.php?report=${reportType}`)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        outputDiv.innerHTML = `<p style="color: var(--accent-danger); text-align: center;">Error: ${data.error}</p>`;
                        return;
                    }
                    if (data.length === 0) {
                        outputDiv.innerHTML = '<p style="color: var(--text-muted); text-align: center;">No data found for this report.</p>';
                        return;
                    }

                    const headers = Object.keys(data[0]);
                    let table = '<table class="report-table"><thead><tr>';
                    headers.forEach(header => {
                        table += `<th>${header.replace(/_/g, ' ')}</th>`;
                    });
                    table += '</tr></thead><tbody>';

                    data.forEach(row => {
                        table += '<tr>';
                        headers.forEach(header => {
                            const cellData = row[header] ? new Option(row[header]).innerHTML : '';
                            table += `<td>${cellData}</td>`;
                        });
                        table += '</tr>';
                    });

                    table += '</tbody></table>';
                    outputDiv.innerHTML = table;
                })
                .catch(error => {
                    console.error('Fetch Error:', error);
                    outputDiv.innerHTML = '<p style="color: var(--accent-danger); text-align: center;">An error occurred while fetching the report.</p>';
                });
        });
        <?php endif; ?>
    </script>
</body>
</html>
<?php $conn->close(); ?>
